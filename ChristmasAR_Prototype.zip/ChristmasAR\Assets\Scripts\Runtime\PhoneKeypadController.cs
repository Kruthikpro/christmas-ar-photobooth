using System;
using System.Text;
using UnityEngine;

namespace ChristmasAR
{
    /// <summary>Phone number entry model for the SMS keypad (digits, * and #).</summary>
    public class PhoneKeypadController : MonoBehaviour
    {
        [SerializeField] int maxDigits = 14;
        [SerializeField] int minDigitsToSend = 6;

        readonly StringBuilder digits = new StringBuilder(16);
        readonly StringBuilder formatted = new StringBuilder(24);

        public event Action Changed;

        public int Length => digits.Length;
        public bool CanSend => digits.Length >= minDigitsToSend;

        public void Press(char c)
        {
            if (digits.Length >= maxDigits) return;
            if (!char.IsDigit(c) && c != '*' && c != '#') return;
            digits.Append(c);
            Changed?.Invoke();
        }

        public void Backspace()
        {
            if (digits.Length == 0) return;
            digits.Length--;
            Changed?.Invoke();
        }

        public void Clear()
        {
            if (digits.Length == 0) return;
            digits.Length = 0;
            Changed?.Invoke();
        }

        /// <summary>Digits grouped for readability, e.g. "987 654 3210".</summary>
        public string Formatted()
        {
            formatted.Length = 0;
            for (int i = 0; i < digits.Length; i++)
            {
                if (i == 3 || i == 6 || i == 10) formatted.Append(' ');
                formatted.Append(digits[i]);
            }
            return formatted.ToString();
        }
    }
}
