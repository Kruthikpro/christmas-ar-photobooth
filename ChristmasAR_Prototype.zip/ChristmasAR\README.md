# Christmas AR Interactive Prototype

A Christmas AR photo booth you can run on a normal Windows PC. Your laptop webcam supplies the live camera picture. Unity draws a waving 3D Santa next to you, plus snow and a Christmas photo frame on top. A red, portrait-style kiosk interface walks you through the rest: Touch to Start → Merry Christmas → Take Photo → share by Email, SMS or QR code → phone keypad → Sent → back to Home.

Nothing is imported: every texture, sprite, sound and the Santa model are created in code when the app runs, so there are no external assets to go missing.

## Unity version
**Unity 6000.5.8f1** with URP. Do not upgrade or downgrade.

## How to open
1. In Unity Hub, click **Add → Add project from disk** and select the `ChristmasAR` folder.
2. Open it with **6000.5.8f1**. Unity downloads the packages listed in `Packages/manifest.json`; this first step needs internet.
3. If Unity asks whether to enable the new Input System backend, click **Yes**. The project works with the old input system, the new one, or both.
4. After the first import, the editor setup script runs on its own. It:
   - creates and assigns the URP asset (`Assets/Settings`)
   - creates the Santa material (`Assets/Materials`)
   - builds `Assets/Scenes/Main_AR_Christmas.unity` with every component and reference connected
   - adds the scene to Build Settings and opens it

   You can rerun any of this from the **Christmas AR** menu: **Open Main Scene** or **Rebuild Main Scene**.

## How to run
- Open `Main_AR_Christmas` and press **Play**.
- For the kiosk look, set the Game view to a portrait resolution such as **1080x1920**. Landscape also works; the UI stays centred.
- To build a standalone app: **File → Build Profiles → Windows → Build**.

## Webcam
- The first webcam found is used and shown full screen, filling the view, with the image mirrored like a selfie camera.
- If Windows blocks the camera, go to **Settings → Privacy & security → Camera** and turn on camera access for desktop apps. Close any other app that is using the camera, such as Teams or Zoom.
- If there is no webcam, or it fails to start within 5 seconds, a simulated camera picture (a room with a person) is used instead, so the demo never breaks.
- **Demo Mode**: on the `Experience Flow` object, enable **GameStateManager → Demo Mode** to always use the simulated picture.
- To pick a specific camera, enter part of its name in **WebcamController → Preferred Device Name**.

## Keyboard controls
| Key | Action |
|---|---|
| Space | Touch to Start / continue to the next screen |
| P | Take photo |
| H | Home |
| S | Open the SMS keypad (on the share screen) |
| E | Open email entry (on the share screen) |
| Esc | Back |
| 0–9, Backspace, Enter | Type, delete and send on the phone keypad |

Mouse and touch work on every button.

## Demo script (about 60 seconds)
1. **AR camera**: Santa pops in beside you and waves. The gold photo frame and snow sit on top of the live camera picture. Wait about 8 seconds or press Space.
2. **Christmas home**: "Merry Christmas" fades in. Then a pulsing **TOUCH TO START** button appears, with swinging ornaments, light rays and drifting light spots behind it.
3. **Merry Christmas**: Santa appears inside the glowing circle. Press **TAKE PHOTO**.
4. **Photo capture**: the view goes back to the camera with Santa next to you. A 3-2-1 countdown plays, then a flash and shutter sound. The saved photo includes Santa, the frame and the snow, but not the buttons.
5. **Share menu**: shows the photo preview with **EMAIL**, **SMS**, **QR CODE**, **RETAKE** and **HOME**.
6. **SMS**: opens a working keypad with BACK (deletes the last digit), SEND and HOME. **SEND** shows an animated "Sent!" confirmation.
7. After the confirmation, the app returns to the Christmas landing screen on its own.

Photos are also saved as PNG files in `%USERPROFILE%\AppData\LocalLow\Christmas AR Prototype\Christmas AR Experience\ChristmasAR_Photos`.

## Replacing Santa
Select the **Santa** object. In **SantaController → Custom Model Prefab**, assign your own model. Its pivot should be at the feet and it should face **-Z**. Set **Center Height** to roughly half the model's height. The pop-in, sway and bob animations still apply. The procedural arm and head animations only apply to the built-in Santa.

## Adjusting Santa's position and scale
On **AR System → ARCameraController**:
- **Santa Scale**: overall size multiplier.
- **Beside User Pose**: Santa's position in the camera view. `viewport` is screen X/Y from 0 to 1, `depth` is distance (larger means smaller on screen), and `yaw` turns him towards the user.
- **Greeting Pose** and **Corner Pose**: Santa's position on the Merry Christmas screen and on the keypad/email screens.

Timing settings are on **GameStateManager**: intro length, countdown, confirmation time and idle timeouts.

## Architecture
| Script | Responsibility |
|---|---|
| `GameStateManager` | The state machine (`AppState` enum); connects the other systems; maps keyboard shortcuts to actions |
| `WebcamController` | Webcam setup, fill-the-screen sizing, mirroring, simulated-camera fallback |
| `ARCameraController` | Places Santa relative to the camera (the AR anchor layer) |
| `SantaController` | Builds the Santa model and plays his idle, breathing, head and wave animations |
| `ChristmasUIController` | Builds every screen at runtime, handles fades, raises `UIAction` events |
| `PhotoCaptureController` | End-of-frame screenshot with the button layer hidden; PNG save |
| `ShareController` | QR-style code generation; simulated email/SMS sending |
| `PhoneKeypadController` | Phone-number entry |
| `AudioController` | Generates the music (Jingle Bells on bells) and the click, whoosh, shutter, beep and success sounds |
| `ParticleController` | Snow, light spots, ornaments, light rays and gradient motion, using reused objects with no per-frame allocations |

Draw order, back to front:
1. Background canvas (screen-space camera): webcam picture and red background
2. 3D Santa
3. Frame canvas: snow and photo frame
4. UI canvas: buttons

## Known limitations
- No real body tracking. Santa sits at a fixed, adjustable spot on screen next to where the user stands.
- Email and SMS are not actually sent; the confirmation is simulated. The QR code is for show only and does not scan to a real link.
- The Santa model is built from simple shapes. Replace it with a rigged model for production.
- The fonts are Unity's built-in runtime font, not a decorative script font.

## Upgrading to AR Foundation later
1. Install AR Foundation and the ARCore or ARKit plug-in, and add an `XR Origin` with its camera.
2. Replace `WebcamController` with AR Foundation's camera background; the webcam picture's `RawImage` is no longer needed.
3. In `ARCameraController.ComputePose()`, take the pose from an `ARAnchor` or `ARHumanBodyManager` instead of the fixed screen position.
4. Nothing else needs to change: the state machine, UI, photo capture, sharing and keypad do not depend on the camera source.
