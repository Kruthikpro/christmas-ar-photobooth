using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace ChristmasAR.EditorTools
{
    /// <summary>
    /// One-click (and automatic, on first open) project setup: URP asset, materials, the
    /// Main_AR_Christmas scene with every system wired via serialized references, and build settings.
    /// </summary>
    [InitializeOnLoad]
    public static class ChristmasProjectSetup
    {
        public const string ScenePath = "Assets/Scenes/Main_AR_Christmas.unity";
        const string SettingsFolder = "Assets/Settings";
        const string MaterialsFolder = "Assets/Materials";
        const string RendererPath = SettingsFolder + "/ChristmasAR_URP_Renderer.asset";
        const string PipelinePath = SettingsFolder + "/ChristmasAR_URP.asset";
        const string SantaMaterialPath = MaterialsFolder + "/Santa_Base.mat";
        const string AutoOpenKey = "ChristmasAR.AutoOpened";

        static ChristmasProjectSetup()
        {
            EditorApplication.delayCall += OnEditorReady;
        }

        static void OnEditorReady()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += OnEditorReady;
                return;
            }

            if (!File.Exists(ScenePath))
            {
                BuildScene();
                return;
            }

            EnsureRenderPipeline();
            if (!SessionState.GetBool(AutoOpenKey, false))
            {
                SessionState.SetBool(AutoOpenKey, true);
                var active = SceneManager.GetActiveScene();
                if (string.IsNullOrEmpty(active.path) && !active.isDirty) EditorSceneManager.OpenScene(ScenePath);
            }
        }

        [MenuItem("Christmas AR/Open Main Scene", priority = 0)]
        public static void OpenMainScene()
        {
            if (!File.Exists(ScenePath)) { BuildScene(); return; }
            if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) EditorSceneManager.OpenScene(ScenePath);
        }

        [MenuItem("Christmas AR/Rebuild Main Scene", priority = 1)]
        public static void RebuildMenu()
        {
            if (EditorUtility.DisplayDialog("Christmas AR", "Rebuild the Main_AR_Christmas scene from scratch?\nInspector tweaks in the scene will be reset.", "Rebuild", "Cancel"))
                BuildScene();
        }

        public static void BuildScene()
        {
            EnsureFolder("Assets/Scenes");
            EnsureFolder(MaterialsFolder);
            var pipeline = EnsureRenderPipeline();
            var santaMaterial = EnsureSantaMaterial(pipeline != null);

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Camera
            var camGo = new GameObject("AR Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.08f, 0f, 0.02f);
            cam.fieldOfView = 50f;
            cam.nearClipPlane = 0.1f;
            cam.farClipPlane = 150f;
            camGo.AddComponent<AudioListener>();

            // Lighting
            var key = new GameObject("Key Light").AddComponent<Light>();
            key.type = LightType.Directional;
            key.intensity = 1.25f;
            key.color = new Color(1f, 0.95f, 0.88f);
            key.shadows = LightShadows.None;
            key.transform.rotation = Quaternion.Euler(35f, -25f, 0f);
            var fill = new GameObject("Fill Light").AddComponent<Light>();
            fill.type = LightType.Directional;
            fill.intensity = 0.45f;
            fill.color = new Color(0.8f, 0.85f, 1f);
            fill.shadows = LightShadows.None;
            fill.transform.rotation = Quaternion.Euler(15f, 35f, 0f);
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.55f, 0.48f, 0.48f);
            RenderSettings.skybox = null;

            // Systems
            var arGo = new GameObject("AR System");
            var webcam = arGo.AddComponent<WebcamController>();
            var ar = arGo.AddComponent<ARCameraController>();

            var santa = new GameObject("Santa").AddComponent<SantaController>();

            var uiGo = new GameObject("Christmas UI");
            var ui = uiGo.AddComponent<ChristmasUIController>();
            var particles = uiGo.AddComponent<ParticleController>();

            var flowGo = new GameObject("Experience Flow");
            var photo = flowGo.AddComponent<PhotoCaptureController>();
            var share = flowGo.AddComponent<ShareController>();
            var keypad = flowGo.AddComponent<PhoneKeypadController>();
            var audio = new GameObject("Audio").AddComponent<AudioController>();
            var gm = flowGo.AddComponent<GameStateManager>();

            Assign(santa, "baseMaterial", santaMaterial);
            Assign(ar, "arCamera", cam);
            Assign(ar, "santa", santa);
            Assign(gm, "arCamera", cam);
            Assign(gm, "webcam", webcam);
            Assign(gm, "arController", ar);
            Assign(gm, "santa", santa);
            Assign(gm, "ui", ui);
            Assign(gm, "particles", particles);
            Assign(gm, "photo", photo);
            Assign(gm, "share", share);
            Assign(gm, "keypad", keypad);
            Assign(gm, "audioController", audio);

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

            PlayerSettings.productName = "Christmas AR Experience";
            PlayerSettings.companyName = "Christmas AR Prototype";
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.runInBackground = true;

            AssetDatabase.SaveAssets();
            SessionState.SetBool(AutoOpenKey, true);
            Debug.Log("[Christmas AR] Scene built at " + ScenePath + ". Press Play to run the experience.");
        }

        static RenderPipelineAsset EnsureRenderPipeline()
        {
            try
            {
                EnsureFolder(SettingsFolder);
                var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
                if (pipeline == null)
                {
                    var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
                    if (renderer == null)
                    {
                        renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                        AssetDatabase.CreateAsset(renderer, RendererPath);
                    }
                    pipeline = UniversalRenderPipelineAsset.Create(renderer);
                    AssetDatabase.CreateAsset(pipeline, PipelinePath);
                    AssetDatabase.SaveAssets();
                }

                if (GraphicsSettings.defaultRenderPipeline == null)
                {
                    GraphicsSettings.defaultRenderPipeline = pipeline;
                    Debug.Log("[Christmas AR] URP configured as the default render pipeline.");
                }
                if (QualitySettings.renderPipeline == null) QualitySettings.renderPipeline = GraphicsSettings.defaultRenderPipeline;
                return GraphicsSettings.defaultRenderPipeline;
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("[Christmas AR] Could not configure URP automatically (" + e.Message + "). The prototype still runs; assign a URP asset in Project Settings > Graphics.");
                return GraphicsSettings.defaultRenderPipeline;
            }
        }

        static Material EnsureSantaMaterial(bool urp)
        {
            var mat = AssetDatabase.LoadAssetAtPath<Material>(SantaMaterialPath);
            if (mat != null) return mat;
            Shader shader = urp ? Shader.Find("Universal Render Pipeline/Lit") : null;
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            mat = new Material(shader) { name = "Santa_Base" };
            if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", 0.3f);
            AssetDatabase.CreateAsset(mat, SantaMaterialPath);
            return mat;
        }

        static void Assign(Object target, string field, Object value)
        {
            var so = new SerializedObject(target);
            var prop = so.FindProperty(field);
            if (prop == null)
            {
                Debug.LogWarning("[Christmas AR] Field '" + field + "' not found on " + target.GetType().Name);
                return;
            }
            prop.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            string leaf = Path.GetFileName(path);
            if (!AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, leaf);
        }
    }
}
