using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ChristmasAR
{
    /// <summary>Hover / press scale animation, optional idle pulse and soft gold glow for kiosk buttons.</summary>
    public class UIButtonFx : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
    {
        [SerializeField] bool pulse;
        [SerializeField] float pulseSpeed = 2.6f;
        [SerializeField] float pulseAmount = 0.04f;
        [SerializeField] float hoverScale = 1.07f;
        [SerializeField] float pressScale = 0.92f;

        Image glow;
        bool hover, down;
        float phase;

        public void Setup(Image glowImage, bool pulseEnabled)
        {
            glow = glowImage;
            pulse = pulseEnabled;
            phase = Random.value * 6.28f;
        }

        void OnDisable()
        {
            hover = down = false;
            transform.localScale = Vector3.one;
        }

        void Update()
        {
            float dt = Time.unscaledDeltaTime;
            float t = Time.unscaledTime * pulseSpeed + phase;
            float wave = Mathf.Sin(t) * 0.5f + 0.5f;

            float target = down ? pressScale : (hover ? hoverScale : 1f);
            if (pulse && !down) target += (wave - 0.5f) * 2f * pulseAmount;
            float s = Mathf.Lerp(transform.localScale.x, target, 1f - Mathf.Exp(-18f * dt));
            transform.localScale = new Vector3(s, s, 1f);

            if (glow != null)
            {
                float a = (pulse ? 0.18f + 0.25f * wave : 0f) + (hover ? 0.3f : 0f);
                var c = glow.color;
                c.a = Mathf.Lerp(c.a, a, 1f - Mathf.Exp(-10f * dt));
                glow.color = c;
            }
        }

        public void OnPointerEnter(PointerEventData eventData) { hover = true; }
        public void OnPointerExit(PointerEventData eventData) { hover = false; down = false; }
        public void OnPointerDown(PointerEventData eventData) { down = true; }
        public void OnPointerUp(PointerEventData eventData) { down = false; }
    }
}
