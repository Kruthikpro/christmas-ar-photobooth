namespace ChristmasAR
{
    /// <summary>Top-level states of the installation flow.</summary>
    public enum AppState
    {
        AR_CAMERA,
        CHRISTMAS_HOME,
        TOUCH_TO_START,
        MERRY_CHRISTMAS,
        PHOTO_CAPTURE,
        SHARE_MENU,
        PHONE_KEYPAD,
        EMAIL_ENTRY,
        SEND_CONFIRMATION,
        RETURN_HOME
    }

    /// <summary>User intents raised by the UI or keyboard and handled by the GameStateManager.</summary>
    public enum UIAction
    {
        Continue,
        Start,
        Home,
        TakePhoto,
        Retake,
        Email,
        Sms,
        Qr,
        CloseQr,
        Send,
        Back,
        KeypadBack
    }

    /// <summary>Where Santa is anchored for the current state.</summary>
    public enum SantaMode
    {
        Hidden,
        BesideUser,
        Greeting,
        Corner
    }

    public enum Sfx
    {
        Click,
        Transition,
        Shutter,
        Success,
        Beep
    }
}
