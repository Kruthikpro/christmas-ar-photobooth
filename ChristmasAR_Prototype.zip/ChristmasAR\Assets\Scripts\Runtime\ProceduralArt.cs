using UnityEngine;

namespace ChristmasAR
{
    /// <summary>Generates every texture the prototype needs, so it never depends on imported art.</summary>
    public static class ProceduralArt
    {
        static Texture2D NewTexture(int w, int h, string name, FilterMode filter = FilterMode.Bilinear)
        {
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.name = name;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = filter;
            return tex;
        }

        static float Hash(float x, float y)
        {
            float h = Mathf.Sin(x * 127.1f + y * 311.7f) * 43758.5453f;
            return h - Mathf.Floor(h);
        }

        /// <summary>Deep red radial gradient with subtle low-poly facets (matches the kiosk background).</summary>
        public static Texture2D FestiveGradient(int w = 256, int h = 512)
        {
            var tex = NewTexture(w, h, "FestiveGradient");
            var px = new Color32[w * h];
            Color bright = new Color(0.86f, 0.10f, 0.13f);
            Color deep = new Color(0.28f, 0.01f, 0.04f);
            const float cellsX = 6f, cellsY = 11f;

            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
                    float dx = (u - 0.5f) * 1.1f, dy = (v - 0.6f) * 1.6f;
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    Color c = Color.Lerp(bright, deep, Mathf.SmoothStep(0f, 1f, d * 1.25f));

                    float fx = u * cellsX, fy = v * cellsY;
                    float cx = Mathf.Floor(fx), cy = Mathf.Floor(fy);
                    float tri = (fx - cx) > (fy - cy) ? 1f : 0f;
                    float facet = (Hash(cx + tri * 0.37f, cy) - 0.5f) * 0.10f;

                    c.r = Mathf.Clamp01(c.r + facet);
                    c.g = Mathf.Clamp01(c.g + facet * 0.2f);
                    c.b = Mathf.Clamp01(c.b + facet * 0.3f);
                    c.a = 1f;
                    px[y * w + x] = c;
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            return tex;
        }

        /// <summary>Soft radial light rays (white, alpha-only) to be tinted and slowly rotated.</summary>
        public static Texture2D LightRays(int size = 256, int halfRays = 6)
        {
            var tex = NewTexture(size, size, "LightRays");
            var px = new Color32[size * size];
            float c = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x + 0.5f - c, dy = y + 0.5f - c;
                    float r = Mathf.Sqrt(dx * dx + dy * dy) / c;
                    float angle = Mathf.Atan2(dy, dx);
                    float rays = Mathf.Pow(Mathf.Abs(Mathf.Cos(angle * halfRays)), 8f);
                    float fall = Mathf.Clamp01(1f - r);
                    fall *= fall;
                    float a = Mathf.Clamp01(rays * fall + fall * fall * 0.3f);
                    px[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            return tex;
        }

        /// <summary>Stand-in camera feed for Demo Mode / no webcam: a warm room with a person silhouette.</summary>
        public static Texture2D SimulatedCamera(int w = 640, int h = 360)
        {
            var tex = NewTexture(w, h, "SimulatedCameraFeed");
            var px = new Color32[w * h];
            float aspect = (float)w / h;
            Color warm = new Color(1f, 0.78f, 0.45f);
            Color sweater = new Color(0.16f, 0.25f, 0.55f);
            Color jeans = new Color(0.35f, 0.50f, 0.70f);
            Color skin = new Color(0.85f, 0.65f, 0.55f);
            Color hair = new Color(0.12f, 0.08f, 0.06f);

            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
                    Color c = Color.Lerp(new Color(0.16f, 0.13f, 0.12f), new Color(0.34f, 0.27f, 0.22f), v);
                    if (v < 0.22f) c = Color.Lerp(new Color(0.10f, 0.08f, 0.08f), new Color(0.20f, 0.16f, 0.14f), v / 0.22f);
                    if (u > 0.08f && u < 0.24f && v > 0.22f && v < 0.9f) c = Color.Lerp(c, new Color(0.12f, 0.16f, 0.20f), 0.8f);

                    // String lights along the top.
                    for (int k = 0; k < 14; k++)
                    {
                        float lx = (k + 0.5f) / 14f;
                        float ly = 0.86f + Mathf.Sin(k * 1.7f) * 0.04f;
                        float ddx = (u - lx) * aspect, ddy = v - ly;
                        float glow = Mathf.Exp(-(ddx * ddx + ddy * ddy) * 900f);
                        c += warm * (glow * 0.9f);
                    }

                    // Person silhouette.
                    float pxn = (u - 0.45f) * aspect;
                    float headDy = v - 0.70f;
                    if (pxn * pxn + headDy * headDy < 0.085f * 0.085f)
                        c = headDy > 0.04f ? hair : skin;
                    else if (v < 0.60f && v >= 0.30f && Mathf.Abs(pxn) < Mathf.Lerp(0.13f, 0.17f, (v - 0.30f) / 0.30f))
                        c = sweater;
                    else if (v < 0.30f && v > 0.02f && Mathf.Abs(Mathf.Abs(pxn) - 0.055f) < 0.045f)
                        c = jeans;

                    c.a = 1f;
                    px[y * w + x] = c;
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            return tex;
        }

        /// <summary>QR-style visual (finder patterns + timing + pseudo-random modules). Demonstration only.</summary>
        public static Texture2D QrStyle(int modules, int seed)
        {
            const int quiet = 2;
            int size = modules + quiet * 2;
            var tex = NewTexture(size, size, "QrCode", FilterMode.Point);
            var px = new Color32[size * size];
            var rng = new System.Random(seed);
            var dark = new Color32(20, 10, 12, 255);
            var light = new Color32(255, 255, 255, 255);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    int mx = x - quiet, my = y - quiet;
                    bool on = false;
                    if (mx >= 0 && my >= 0 && mx < modules && my < modules)
                    {
                        if (Finder(mx, my, modules, out bool f)) on = f;
                        else if (mx == 6) on = my % 2 == 0;
                        else if (my == 6) on = mx % 2 == 0;
                        else on = rng.NextDouble() < 0.48;
                    }
                    px[y * size + x] = on ? dark : light;
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            return tex;
        }

        static bool Finder(int x, int y, int n, out bool on)
        {
            int fx, fy;
            if (x < 8 && y < 8) { fx = x; fy = y; }
            else if (x >= n - 8 && y < 8) { fx = x - (n - 7); fy = y; }
            else if (x < 8 && y >= n - 8) { fx = x; fy = y - (n - 7); }
            else { on = false; return false; }

            if (fx < 0 || fy < 0 || fx > 6 || fy > 6) { on = false; return true; }
            int d = Mathf.Max(Mathf.Abs(fx - 3), Mathf.Abs(fy - 3));
            on = d != 2;
            return true;
        }
    }
}
