using UnityEngine;

namespace ChristmasAR
{
    /// <summary>
    /// Plays ambient music and UI sounds. Any clip left empty is synthesised procedurally at startup
    /// (a soft bell rendition of Jingle Bells, clicks, whoosh, shutter, success chime), so the build never
    /// depends on audio assets.
    /// </summary>
    public class AudioController : MonoBehaviour
    {
        [Header("Optional overrides (procedural sounds are used when empty)")]
        [SerializeField] AudioClip musicClip;
        [SerializeField] AudioClip clickClip;
        [SerializeField] AudioClip transitionClip;
        [SerializeField] AudioClip shutterClip;
        [SerializeField] AudioClip successClip;
        [SerializeField] AudioClip beepClip;

        [Header("Mix")]
        [SerializeField] bool playMusic = true;
        [SerializeField, Range(0f, 1f)] float musicVolume = 0.25f;
        [SerializeField, Range(0f, 1f)] float sfxVolume = 0.8f;

        const int SampleRate = 22050;
        AudioSource musicSource, sfxSource;
        bool initialized;

        public void Initialize()
        {
            if (initialized) return;
            initialized = true;

            musicSource = gameObject.AddComponent<AudioSource>();
            musicSource.playOnAwake = false;
            musicSource.loop = true;
            musicSource.spatialBlend = 0f;
            musicSource.volume = musicVolume;

            sfxSource = gameObject.AddComponent<AudioSource>();
            sfxSource.playOnAwake = false;
            sfxSource.spatialBlend = 0f;

            if (clickClip == null) clickClip = Build("Click", ClickData());
            if (beepClip == null) beepClip = Build("Beep", BeepData());
            if (transitionClip == null) transitionClip = Build("Transition", TransitionData());
            if (shutterClip == null) shutterClip = Build("Shutter", ShutterData());
            if (successClip == null) successClip = Build("Success", SuccessData());
            if (musicClip == null) musicClip = Build("ChristmasAmbient", MusicData());
        }

        public void PlayMusic()
        {
            if (!playMusic || musicSource == null || musicClip == null) return;
            musicSource.clip = musicClip;
            musicSource.volume = musicVolume;
            if (!musicSource.isPlaying) musicSource.Play();
        }

        public void Play(Sfx sfx)
        {
            if (sfxSource == null) return;
            AudioClip clip = sfx switch
            {
                Sfx.Click => clickClip,
                Sfx.Transition => transitionClip,
                Sfx.Shutter => shutterClip,
                Sfx.Success => successClip,
                Sfx.Beep => beepClip,
                _ => null
            };
            if (clip != null) sfxSource.PlayOneShot(clip, sfxVolume);
        }

        // ---------------------------------------------------------------- synthesis

        static AudioClip Build(string name, float[] data)
        {
            var clip = AudioClip.Create(name, data.Length, 1, SampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }

        static float[] Buffer(float seconds) => new float[Mathf.CeilToInt(seconds * SampleRate)];
        static float Midi(float note) => 440f * Mathf.Pow(2f, (note - 69f) / 12f);

        static void AddBell(float[] buf, float startSec, float freq, float dur, float vol, float decay = 3.5f, bool wrap = false)
        {
            int start = (int)(startSec * SampleRate);
            int len = (int)(dur * SampleRate);
            float w = 2f * Mathf.PI * freq / SampleRate;
            for (int i = 0; i < len; i++)
            {
                int idx = start + i;
                if (idx >= buf.Length)
                {
                    if (!wrap) break;
                    idx %= buf.Length;
                }
                float t = i / (float)SampleRate;
                float env = Mathf.Exp(-t * decay) * Mathf.Min(1f, t * 400f);
                float s = Mathf.Sin(w * i)
                          + 0.45f * Mathf.Sin(2f * w * i) * Mathf.Exp(-t * 4f)
                          + 0.20f * Mathf.Sin(3.01f * w * i) * Mathf.Exp(-t * 6f);
                buf[idx] += s * env * vol;
            }
        }

        static void AddNoise(float[] buf, float startSec, float dur, float vol, float decay, System.Random rng, bool highPass)
        {
            int start = (int)(startSec * SampleRate);
            int len = (int)(dur * SampleRate);
            float lp = 0f;
            for (int i = 0; i < len; i++)
            {
                int idx = start + i;
                if (idx >= buf.Length) idx %= buf.Length;
                float n = (float)rng.NextDouble() * 2f - 1f;
                lp += 0.25f * (n - lp);
                float s = highPass ? n - lp : lp;
                float t = i / (float)SampleRate;
                buf[idx] += s * Mathf.Exp(-t * decay) * vol;
            }
        }

        static void Normalize(float[] buf, float peak)
        {
            float max = 0f;
            for (int i = 0; i < buf.Length; i++) max = Mathf.Max(max, Mathf.Abs(buf[i]));
            if (max < 1e-5f) return;
            float k = peak / max;
            for (int i = 0; i < buf.Length; i++) buf[i] *= k;
        }

        static float[] ClickData()
        {
            var b = Buffer(0.07f);
            AddBell(b, 0f, 1500f, 0.07f, 0.6f, 60f);
            AddBell(b, 0f, 3000f, 0.05f, 0.2f, 80f);
            Normalize(b, 0.5f);
            return b;
        }

        static float[] BeepData()
        {
            var b = Buffer(0.3f);
            AddBell(b, 0f, 880f, 0.3f, 0.5f, 10f);
            Normalize(b, 0.45f);
            return b;
        }

        static float[] TransitionData()
        {
            var b = Buffer(0.6f);
            var rng = new System.Random(7);
            float y = 0f;
            for (int i = 0; i < b.Length; i++)
            {
                float t = i / (float)b.Length;
                float a = Mathf.Lerp(0.02f, 0.35f, t);
                y += a * ((float)rng.NextDouble() * 2f - 1f - y);
                b[i] = y * Mathf.Sin(Mathf.PI * t) * 0.6f;
            }
            AddBell(b, 0.05f, Midi(88), 0.5f, 0.15f, 6f);
            AddBell(b, 0.15f, Midi(91), 0.45f, 0.12f, 6f);
            AddBell(b, 0.25f, Midi(96), 0.35f, 0.10f, 6f);
            Normalize(b, 0.4f);
            return b;
        }

        static float[] ShutterData()
        {
            var b = Buffer(0.3f);
            var rng = new System.Random(3);
            AddNoise(b, 0f, 0.05f, 0.9f, 60f, rng, true);
            AddNoise(b, 0.09f, 0.08f, 0.7f, 40f, rng, false);
            Normalize(b, 0.7f);
            return b;
        }

        static float[] SuccessData()
        {
            var b = Buffer(1.4f);
            float[] notes = { 72f, 76f, 79f, 84f };
            for (int i = 0; i < notes.Length; i++) AddBell(b, i * 0.09f, Midi(notes[i]), 1.0f, 0.4f, 3f);
            Normalize(b, 0.6f);
            return b;
        }

        // Jingle Bells chorus (MIDI note, beats). 64 beats total so the loop is seamless.
        static readonly float[] Melody =
        {
            76,1, 76,1, 76,2,   76,1, 76,1, 76,2,   76,1, 79,1, 72,1.5f, 74,0.5f,   76,4,
            77,1, 77,1, 77,1.5f, 77,0.5f,   77,1, 76,1, 76,1, 76,0.5f, 76,0.5f,   76,1, 74,1, 74,1, 76,1,   74,2, 79,2,
            76,1, 76,1, 76,2,   76,1, 76,1, 76,2,   76,1, 79,1, 72,1.5f, 74,0.5f,   76,4,
            77,1, 77,1, 77,1.5f, 77,0.5f,   77,1, 76,1, 76,1, 76,0.5f, 76,0.5f,   79,1, 79,1, 77,1, 74,1,   72,4
        };
        static readonly float[] BassRoots = { 48, 48, 48, 48, 53, 48, 50, 55, 48, 48, 48, 48, 53, 48, 55, 48 };

        static float[] MusicData()
        {
            const float beat = 0.3f;
            var b = Buffer(64 * beat);
            float pos = 0f;
            for (int i = 0; i < Melody.Length; i += 2)
            {
                AddBell(b, pos * beat, Midi(Melody[i]), 1.6f, 0.32f, 2.6f, true);
                AddBell(b, pos * beat, Midi(Melody[i] + 12f), 0.6f, 0.06f, 6f, true);
                pos += Melody[i + 1];
            }
            for (int bar = 0; bar < BassRoots.Length; bar++)
            {
                AddBell(b, bar * 4 * beat, Midi(BassRoots[bar]), 1.4f, 0.22f, 1.8f, true);
                AddBell(b, (bar * 4 + 2) * beat, Midi(BassRoots[bar] + 7f), 1.2f, 0.16f, 2f, true);
            }
            var rng = new System.Random(11);
            for (int i = 1; i < 64; i += 2) AddNoise(b, i * beat, 0.08f, 0.05f, 30f, rng, true);
            Normalize(b, 0.8f);
            return b;
        }
    }
}
