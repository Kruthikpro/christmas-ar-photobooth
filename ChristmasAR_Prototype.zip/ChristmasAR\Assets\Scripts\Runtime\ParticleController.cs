using UnityEngine;
using UnityEngine.UI;

namespace ChristmasAR
{
    /// <summary>
    /// Lightweight UI-space effects: falling snow, drifting bokeh, swinging ornaments, rotating light rays
    /// and a slowly moving gradient. Everything is pooled once; Update performs no allocations.
    /// </summary>
    public class ParticleController : MonoBehaviour
    {
        [Header("Snow")]
        [SerializeField, Range(0, 200)] int snowCount = 70;
        [SerializeField] Vector2 snowSize = new Vector2(6f, 18f);
        [SerializeField] Vector2 snowFallSpeed = new Vector2(40f, 130f);
        [SerializeField] float snowDrift = 30f;

        [Header("Festive background")]
        [SerializeField, Range(0, 40)] int bokehCount = 14;
        [SerializeField, Range(0, 12)] int ornamentCount = 7;
        [SerializeField] float raySpinSpeed = 4f;

        RectTransform snowRoot;
        RectTransform[] flakes;
        Vector2[] flakePos;
        float[] flakeSpeed, flakePhase;
        bool snowSeeded;

        RectTransform[] bokeh;
        Image[] bokehImg;
        Vector2[] bokehPos;
        float[] bokehSpeed, bokehPhase, bokehAlpha;

        RectTransform[] ornaments;
        float[] ornPhase, ornSpeed, ornAmp;

        RectTransform rays, gradient;
        Texture2D gradientTex, raysTex;

        public void BuildSnow(RectTransform parent)
        {
            if (parent == null || flakes != null) return;
            snowRoot = UIFactory.Stretch(UIFactory.MakeRect("Snow", parent));
            flakes = new RectTransform[snowCount];
            flakePos = new Vector2[snowCount];
            flakeSpeed = new float[snowCount];
            flakePhase = new float[snowCount];
            for (int i = 0; i < snowCount; i++)
            {
                var img = UIFactory.MakeImage("Flake", snowRoot, UIFactory.SoftCircle, new Color(1f, 1f, 1f, Random.Range(0.45f, 0.95f)));
                var rt = img.rectTransform;
                rt.anchorMin = rt.anchorMax = Vector2.zero;
                float s = Random.Range(snowSize.x, snowSize.y);
                rt.sizeDelta = new Vector2(s, s);
                flakes[i] = rt;
                float k = Mathf.InverseLerp(snowSize.x, snowSize.y, s);
                flakeSpeed[i] = Mathf.Lerp(snowFallSpeed.x, snowFallSpeed.y, k) * Random.Range(0.85f, 1.15f);
                flakePhase[i] = Random.value * 6.28f;
            }
        }

        public void BuildFestiveBackground(RectTransform parent)
        {
            if (parent == null || gradient != null) return;
            gradientTex = ProceduralArt.FestiveGradient();
            raysTex = ProceduralArt.LightRays();

            gradient = UIFactory.Stretch(UIFactory.MakeRaw("Gradient", parent, gradientTex, Color.white).rectTransform, -80f);

            var ray = UIFactory.MakeRaw("LightRays", parent, raysTex, new Color(1f, 0.85f, 0.6f, 0.16f));
            rays = UIFactory.Place(ray.rectTransform, new Vector2(0.5f, 0.72f), Vector2.zero, new Vector2(3200f, 3200f));

            var bokehRoot = UIFactory.Stretch(UIFactory.MakeRect("Bokeh", parent));
            bokeh = new RectTransform[bokehCount];
            bokehImg = new Image[bokehCount];
            bokehPos = new Vector2[bokehCount];
            bokehSpeed = new float[bokehCount];
            bokehPhase = new float[bokehCount];
            bokehAlpha = new float[bokehCount];
            for (int i = 0; i < bokehCount; i++)
            {
                Color c = i % 3 == 0 ? Color.white : UIFactory.Gold;
                bokehAlpha[i] = Random.Range(0.06f, 0.22f);
                c.a = bokehAlpha[i];
                var img = UIFactory.MakeImage("Bokeh", bokehRoot, UIFactory.SoftCircle, c);
                float s = Random.Range(60f, 240f);
                bokehPos[i] = new Vector2(Random.Range(-620f, 620f), Random.Range(-1000f, 1000f));
                bokeh[i] = UIFactory.Place(img.rectTransform, new Vector2(0.5f, 0.5f), bokehPos[i], new Vector2(s, s));
                bokehImg[i] = img;
                bokehSpeed[i] = Random.Range(8f, 26f);
                bokehPhase[i] = Random.value * 6.28f;
            }

            var ornRoot = UIFactory.Stretch(UIFactory.MakeRect("Ornaments", parent));
            Color[] palette =
            {
                Color.white, UIFactory.Gold, new Color(0.10f, 0.45f, 0.25f), Color.white,
                new Color(0.95f, 0.25f, 0.25f), UIFactory.Gold, Color.white
            };
            ornaments = new RectTransform[ornamentCount];
            ornPhase = new float[ornamentCount];
            ornSpeed = new float[ornamentCount];
            ornAmp = new float[ornamentCount];
            for (int i = 0; i < ornamentCount; i++)
            {
                float x = ornamentCount == 1 ? 0f : Mathf.Lerp(-460f, 460f, i / (float)(ornamentCount - 1));
                float length = 140f + ((i * 53) % 5) * 55f;
                float ball = 90f + ((i * 37) % 4) * 18f;
                ornaments[i] = BuildOrnament(ornRoot, x, length, ball, palette[i % palette.Length]);
                ornPhase[i] = Random.value * 6.28f;
                ornSpeed[i] = Random.Range(0.8f, 1.4f);
                ornAmp[i] = Random.Range(3f, 7f);
            }
        }

        static RectTransform BuildOrnament(RectTransform parent, float x, float length, float ball, Color color)
        {
            var root = UIFactory.MakeRect("Ornament", parent);
            root.anchorMin = root.anchorMax = new Vector2(0.5f, 1f);
            root.pivot = new Vector2(0.5f, 1f);
            root.anchoredPosition = new Vector2(x, 10f);
            root.sizeDelta = new Vector2(ball, length + ball);

            var str = UIFactory.MakeImage("String", root, null, new Color(1f, 0.9f, 0.7f, 0.8f));
            TopAnchor(str.rectTransform, 0f, new Vector2(3f, length));

            var bal = UIFactory.MakeImage("Ball", root, UIFactory.Circle, color);
            TopAnchor(bal.rectTransform, -length - ball * 0.10f, new Vector2(ball, ball));

            var band = UIFactory.MakeImage("Band", bal.rectTransform, UIFactory.RoundedFill, new Color(1f, 1f, 1f, 0.35f));
            UIFactory.Place(band.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(ball * 0.92f, ball * 0.13f));
            if (color.r > 0.9f && color.g > 0.9f && color.b > 0.9f) band.color = new Color(0.8f, 0.1f, 0.15f, 0.6f);

            var shine = UIFactory.MakeImage("Shine", bal.rectTransform, UIFactory.SoftCircle, new Color(1f, 1f, 1f, 0.6f));
            UIFactory.Place(shine.rectTransform, new Vector2(0.33f, 0.68f), Vector2.zero, new Vector2(ball * 0.45f, ball * 0.45f));

            var cap = UIFactory.MakeImage("Cap", root, UIFactory.RoundedFill, UIFactory.Gold);
            TopAnchor(cap.rectTransform, -length + 4f, new Vector2(ball * 0.32f, ball * 0.2f));
            return root;
        }

        static void TopAnchor(RectTransform rt, float y, Vector2 size)
        {
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, y);
            rt.sizeDelta = size;
        }

        void Update()
        {
            float dt = Time.unscaledDeltaTime, t = Time.unscaledTime;
            if (flakes != null) UpdateSnow(dt, t);

            if (bokeh != null)
            {
                for (int i = 0; i < bokeh.Length; i++)
                {
                    var p = bokehPos[i];
                    p.y += bokehSpeed[i] * dt;
                    if (p.y > 1100f) p.y = -1100f;
                    bokehPos[i] = p;
                    bokeh[i].anchoredPosition = new Vector2(p.x + Mathf.Sin(t * 0.3f + bokehPhase[i]) * 40f, p.y);
                    var c = bokehImg[i].color;
                    c.a = bokehAlpha[i] * (0.6f + 0.4f * Mathf.Sin(t * 0.8f + bokehPhase[i]));
                    bokehImg[i].color = c;
                }
            }

            if (ornaments != null)
            {
                for (int i = 0; i < ornaments.Length; i++)
                    ornaments[i].localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(t * ornSpeed[i] + ornPhase[i]) * ornAmp[i]);
            }

            if (rays != null) rays.localRotation = Quaternion.Euler(0f, 0f, t * raySpinSpeed);
            if (gradient != null)
            {
                gradient.localScale = Vector3.one * (1.04f + Mathf.Sin(t * 0.15f) * 0.025f);
                gradient.anchoredPosition = new Vector2(Mathf.Sin(t * 0.1f) * 20f, Mathf.Cos(t * 0.13f) * 20f);
            }
        }

        void UpdateSnow(float dt, float t)
        {
            Rect r = snowRoot.rect;
            if (r.width <= 1f) return;
            if (!snowSeeded)
            {
                for (int i = 0; i < flakes.Length; i++) flakePos[i] = new Vector2(Random.value * r.width, Random.value * r.height);
                snowSeeded = true;
            }
            for (int i = 0; i < flakes.Length; i++)
            {
                var p = flakePos[i];
                p.y -= flakeSpeed[i] * dt;
                p.x += Mathf.Sin(t * 0.9f + flakePhase[i]) * snowDrift * dt;
                if (p.y < -30f) { p.y = r.height + 30f; p.x = Random.value * r.width; }
                if (p.x < -30f) p.x += r.width + 60f;
                else if (p.x > r.width + 30f) p.x -= r.width + 60f;
                flakePos[i] = p;
                flakes[i].anchoredPosition = p;
            }
        }

        void OnDestroy()
        {
            if (gradientTex != null) Destroy(gradientTex);
            if (raysTex != null) Destroy(raysTex);
        }
    }
}
