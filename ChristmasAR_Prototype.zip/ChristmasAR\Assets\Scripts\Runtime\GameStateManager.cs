using System;
using System.Collections;
using UnityEngine;

namespace ChristmasAR
{
    /// <summary>
    /// Owns the application state machine and wires the independent systems together.
    /// UI raises UIAction events; keyboard shortcuts map onto the same actions.
    /// </summary>
    public class GameStateManager : MonoBehaviour
    {
        [Header("Systems (auto-found if empty)")]
        [SerializeField] Camera arCamera;
        [SerializeField] WebcamController webcam;
        [SerializeField] ARCameraController arController;
        [SerializeField] SantaController santa;
        [SerializeField] ChristmasUIController ui;
        [SerializeField] ParticleController particles;
        [SerializeField] PhotoCaptureController photo;
        [SerializeField] ShareController share;
        [SerializeField] PhoneKeypadController keypad;
        [SerializeField] AudioController audioController;

        [Header("Demo Mode")]
        [Tooltip("Guaranteed demo: uses the simulated camera background even if a webcam is present.")]
        [SerializeField] bool demoMode = false;

        [Header("Timing (seconds)")]
        [SerializeField] float arIntroDuration = 8f;
        [SerializeField] float homeIntroDuration = 1.6f;
        [SerializeField] float countdownSeconds = 3f;
        [SerializeField] float confirmationDuration = 5f;
        [Tooltip("Return to the landing screen after this long without interaction.")]
        [SerializeField] float idleTimeout = 75f;
        [Tooltip("Loop back to the AR attract view if nobody touches the start screen.")]
        [SerializeField] float attractLoopTimeout = 40f;

        public AppState State { get; private set; } = AppState.AR_CAMERA;
        public event Action<AppState, AppState> StateChanged;

        float stateTime, idleTime;
        Coroutine captureRoutine;
        bool ready;

        void Awake()
        {
            if (arCamera == null) arCamera = Camera.main;
            if (webcam == null) webcam = FindAnyObjectByType<WebcamController>();
            if (arController == null) arController = FindAnyObjectByType<ARCameraController>();
            if (santa == null) santa = FindAnyObjectByType<SantaController>();
            if (ui == null) ui = FindAnyObjectByType<ChristmasUIController>();
            if (particles == null) particles = FindAnyObjectByType<ParticleController>();
            if (photo == null) photo = FindAnyObjectByType<PhotoCaptureController>();
            if (share == null) share = FindAnyObjectByType<ShareController>();
            if (keypad == null) keypad = FindAnyObjectByType<PhoneKeypadController>();
            if (audioController == null) audioController = FindAnyObjectByType<AudioController>();
        }

        void Start()
        {
            if (arCamera == null || webcam == null || arController == null || santa == null || ui == null ||
                photo == null || share == null || keypad == null)
            {
                Debug.LogError("[Christmas AR] Scene is missing required systems. Use the menu 'Christmas AR > Rebuild Main Scene'.");
                enabled = false;
                return;
            }

            if (FindAnyObjectByType<AudioListener>() == null) arCamera.gameObject.AddComponent<AudioListener>();
            if (audioController != null) audioController.Initialize();

            santa.Build();
            arController.Initialize(arCamera, santa);
            ui.Build(arCamera, arController.GreetingViewportY, particles);
            ui.ActionInvoked += HandleAction;
            ui.KeypadPressed += OnKeypadPressed;
            keypad.Changed += RefreshKeypad;
            RefreshKeypad();
            ui.SetQrTexture(share.QrTexture);

            if (demoMode) webcam.DemoMode = true;
            webcam.Bind(ui.WebcamImage);
            webcam.Initialize();

            if (audioController != null) audioController.PlayMusic();
            ready = true;
            EnterState(AppState.AR_CAMERA, true);
        }

        void OnDestroy()
        {
            if (ui != null)
            {
                ui.ActionInvoked -= HandleAction;
                ui.KeypadPressed -= OnKeypadPressed;
            }
            if (keypad != null) keypad.Changed -= RefreshKeypad;
        }

        void Update()
        {
            if (!ready) return;
            float dt = Time.unscaledDeltaTime;
            stateTime += dt;
            idleTime += dt;

            HandleKeyboard();

            switch (State)
            {
                case AppState.AR_CAMERA:
                    if (stateTime > arIntroDuration && idleTime > arIntroDuration) SetState(AppState.CHRISTMAS_HOME);
                    break;
                case AppState.CHRISTMAS_HOME:
                    if (stateTime > homeIntroDuration) SetState(AppState.TOUCH_TO_START);
                    break;
                case AppState.RETURN_HOME:
                    if (stateTime > homeIntroDuration) SetState(AppState.TOUCH_TO_START);
                    break;
                case AppState.TOUCH_TO_START:
                    if (idleTime > attractLoopTimeout) SetState(AppState.AR_CAMERA);
                    break;
                case AppState.SEND_CONFIRMATION:
                    if (stateTime > confirmationDuration) SetState(AppState.RETURN_HOME);
                    break;
            }

            bool idleState = State == AppState.AR_CAMERA || State == AppState.CHRISTMAS_HOME ||
                             State == AppState.TOUCH_TO_START || State == AppState.RETURN_HOME ||
                             State == AppState.PHOTO_CAPTURE;
            if (!idleState && idleTime > idleTimeout) SetState(AppState.RETURN_HOME);
        }

        // ---------------------------------------------------------------- input

        void HandleKeyboard()
        {
            if (State == AppState.EMAIL_ENTRY)
            {
                if (InputShortcuts.Pressed(Shortcut.Back)) HandleAction(UIAction.Back);
                else if (InputShortcuts.Pressed(Shortcut.Submit)) HandleAction(UIAction.Send);
                return; // letters are typed into the email field
            }

            if (State == AppState.PHONE_KEYPAD)
            {
                int digit = InputShortcuts.DigitPressed();
                if (digit >= 0) OnKeypadPressed((char)('0' + digit));
                if (InputShortcuts.Pressed(Shortcut.Backspace)) HandleAction(UIAction.KeypadBack);
                if (InputShortcuts.Pressed(Shortcut.Submit)) HandleAction(UIAction.Send);
            }

            if (InputShortcuts.Pressed(Shortcut.Space)) HandleAction(UIAction.Continue);
            else if (InputShortcuts.Pressed(Shortcut.TakePhoto)) HandleAction(UIAction.TakePhoto);
            else if (InputShortcuts.Pressed(Shortcut.Home)) HandleAction(UIAction.Home);
            else if (InputShortcuts.Pressed(Shortcut.Sms)) HandleAction(UIAction.Sms);
            else if (InputShortcuts.Pressed(Shortcut.Email)) HandleAction(UIAction.Email);
            else if (InputShortcuts.Pressed(Shortcut.Back)) HandleAction(UIAction.Back);
        }

        void OnKeypadPressed(char c)
        {
            if (State != AppState.PHONE_KEYPAD) return;
            idleTime = 0f;
            if (audioController != null) audioController.Play(Sfx.Click);
            keypad.Press(c);
        }

        void RefreshKeypad()
        {
            ui.SetKeypadDisplay(keypad.Formatted(), keypad.CanSend);
        }

        void HandleAction(UIAction action)
        {
            idleTime = 0f;
            bool handled = true;
            switch (action)
            {
                case UIAction.Continue: handled = Continue(); break;
                case UIAction.Start:
                    if (State == AppState.TOUCH_TO_START || State == AppState.CHRISTMAS_HOME || State == AppState.RETURN_HOME)
                        SetState(AppState.MERRY_CHRISTMAS);
                    else handled = false;
                    break;
                case UIAction.Home:
                    if (State == AppState.PHOTO_CAPTURE && photo.IsCapturing) { handled = false; break; }
                    SetState(State == AppState.AR_CAMERA ? AppState.CHRISTMAS_HOME : AppState.RETURN_HOME);
                    break;
                case UIAction.TakePhoto:
                case UIAction.Retake:
                    if (State == AppState.AR_CAMERA || State == AppState.MERRY_CHRISTMAS || State == AppState.SHARE_MENU)
                        SetState(AppState.PHOTO_CAPTURE);
                    else handled = false;
                    break;
                case UIAction.Email:
                    if (State == AppState.SHARE_MENU) SetState(AppState.EMAIL_ENTRY); else handled = false;
                    break;
                case UIAction.Sms:
                    if (State == AppState.SHARE_MENU) SetState(AppState.PHONE_KEYPAD); else handled = false;
                    break;
                case UIAction.Qr:
                    if (State == AppState.SHARE_MENU) ui.ShowQr(true); else handled = false;
                    break;
                case UIAction.CloseQr: ui.ShowQr(false); break;
                case UIAction.Send: handled = Send(); break;
                case UIAction.KeypadBack:
                    if (keypad.Length > 0) keypad.Backspace();
                    else SetState(AppState.SHARE_MENU);
                    break;
                case UIAction.Back: handled = GoBack(); break;
            }
            if (handled && audioController != null) audioController.Play(Sfx.Click);
        }

        bool Continue()
        {
            switch (State)
            {
                case AppState.AR_CAMERA: SetState(AppState.CHRISTMAS_HOME); return true;
                case AppState.CHRISTMAS_HOME:
                case AppState.RETURN_HOME:
                case AppState.TOUCH_TO_START: SetState(AppState.MERRY_CHRISTMAS); return true;
                case AppState.MERRY_CHRISTMAS: SetState(AppState.PHOTO_CAPTURE); return true;
                case AppState.SEND_CONFIRMATION: SetState(AppState.RETURN_HOME); return true;
            }
            return false;
        }

        bool GoBack()
        {
            switch (State)
            {
                case AppState.PHONE_KEYPAD:
                case AppState.EMAIL_ENTRY: SetState(AppState.SHARE_MENU); return true;
                case AppState.SHARE_MENU:
                    if (ui.IsQrOpen) ui.ShowQr(false); else SetState(AppState.MERRY_CHRISTMAS);
                    return true;
                case AppState.MERRY_CHRISTMAS: SetState(AppState.TOUCH_TO_START); return true;
                case AppState.PHOTO_CAPTURE:
                    if (photo.IsCapturing) return false;
                    SetState(AppState.MERRY_CHRISTMAS); return true;
                case AppState.SEND_CONFIRMATION: SetState(AppState.RETURN_HOME); return true;
                case AppState.TOUCH_TO_START:
                case AppState.CHRISTMAS_HOME: SetState(AppState.AR_CAMERA); return true;
                case AppState.AR_CAMERA: SetState(AppState.CHRISTMAS_HOME); return true;
            }
            return false;
        }

        bool Send()
        {
            if (State == AppState.PHONE_KEYPAD)
            {
                if (!keypad.CanSend) { ui.ShowKeypadError("Please enter a valid number"); return true; }
                ui.ShowConfirmation("Sent!", share.SimulateSend("SMS", keypad.Formatted()));
                SetState(AppState.SEND_CONFIRMATION);
                return true;
            }
            if (State == AppState.EMAIL_ENTRY)
            {
                string email = ui.EmailText.Trim();
                if (!ShareController.IsValidEmail(email)) { ui.SetEmailError("Please enter a valid email address"); ui.FocusEmail(); return true; }
                ui.ShowConfirmation("Sent!", share.SimulateSend("Email", email));
                SetState(AppState.SEND_CONFIRMATION);
                return true;
            }
            return false;
        }

        // ---------------------------------------------------------------- state machine

        public void SetState(AppState next)
        {
            if (!ready || next == State) return;
            if (State == AppState.PHOTO_CAPTURE && photo.IsCapturing && next != AppState.SHARE_MENU) return;
            EnterState(next, false);
        }

        void EnterState(AppState next, bool initial)
        {
            AppState previous = State;
            if (captureRoutine != null) { StopCoroutine(captureRoutine); captureRoutine = null; }

            State = next;
            stateTime = 0f;
            ui.ShowState(next);
            arController.SetMode(SantaModeFor(next));

            switch (next)
            {
                case AppState.PHOTO_CAPTURE:
                    captureRoutine = StartCoroutine(CaptureSequence());
                    break;
                case AppState.PHONE_KEYPAD:
                    if (previous == AppState.SHARE_MENU) keypad.Clear();
                    RefreshKeypad();
                    break;
                case AppState.EMAIL_ENTRY:
                    ui.ResetEmail();
                    ui.FocusEmail();
                    break;
                case AppState.SEND_CONFIRMATION:
                    if (audioController != null) audioController.Play(Sfx.Success);
                    break;
            }

            if (!initial && audioController != null && next != AppState.SEND_CONFIRMATION) audioController.Play(Sfx.Transition);
            StateChanged?.Invoke(previous, next);
        }

        static SantaMode SantaModeFor(AppState s)
        {
            switch (s)
            {
                case AppState.AR_CAMERA:
                case AppState.PHOTO_CAPTURE: return SantaMode.BesideUser;
                case AppState.MERRY_CHRISTMAS: return SantaMode.Greeting;
                case AppState.PHONE_KEYPAD:
                case AppState.EMAIL_ENTRY:
                case AppState.SEND_CONFIRMATION: return SantaMode.Corner;
                default: return SantaMode.Hidden;
            }
        }

        IEnumerator CaptureSequence()
        {
            ui.SetCountdown("");
            yield return WaitUnscaled(0.7f); // let Santa settle beside the user

            int seconds = Mathf.Max(1, Mathf.RoundToInt(countdownSeconds));
            for (int i = seconds; i >= 1; i--)
            {
                ui.SetCountdown(i.ToString());
                if (audioController != null) audioController.Play(Sfx.Beep);
                yield return WaitUnscaled(1f);
            }
            ui.SetCountdown("");

            bool done = false;
            Texture2D result = null;
            photo.Capture(ui.CaptureHiddenCanvases, tex => { result = tex; done = true; });
            while (!done) yield return null;

            if (audioController != null) audioController.Play(Sfx.Shutter);
            ui.Flash();
            if (result != null)
            {
                ui.SetPhoto(result);
                share.Regenerate(Environment.TickCount);
                ui.SetQrTexture(share.QrTexture);
            }

            yield return WaitUnscaled(0.5f);
            captureRoutine = null;
            SetState(AppState.SHARE_MENU);
        }

        static IEnumerator WaitUnscaled(float seconds)
        {
            float end = Time.unscaledTime + seconds;
            while (Time.unscaledTime < end) yield return null;
        }
    }
}
