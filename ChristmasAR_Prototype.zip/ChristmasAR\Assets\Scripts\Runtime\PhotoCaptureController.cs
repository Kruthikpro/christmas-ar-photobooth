using System;
using System.Collections;
using System.IO;
using UnityEngine;

namespace ChristmasAR
{
    /// <summary>
    /// Captures the composited AR frame (webcam + Santa + Christmas frame/snow) at end of frame,
    /// hiding the interactive UI canvas so buttons never appear in the photo.
    /// </summary>
    public class PhotoCaptureController : MonoBehaviour
    {
        [SerializeField] bool saveToDisk = true;
        [SerializeField] string folderName = "ChristmasAR_Photos";

        Texture2D lastPhoto;

        public Texture2D LastPhoto => lastPhoto;
        public string LastSavedPath { get; private set; }
        public bool IsCapturing { get; private set; }

        public void Capture(Canvas[] hideDuringCapture, Action<Texture2D> onComplete)
        {
            if (IsCapturing) return;
            StartCoroutine(CaptureRoutine(hideDuringCapture, onComplete));
        }

        IEnumerator CaptureRoutine(Canvas[] hide, Action<Texture2D> onComplete)
        {
            IsCapturing = true;
            int count = hide != null ? hide.Length : 0;
            var previous = new bool[count];
            for (int i = 0; i < count; i++)
            {
                if (hide[i] == null) continue;
                previous[i] = hide[i].enabled;
                hide[i].enabled = false;
            }

            yield return new WaitForEndOfFrame();

            Texture2D shot = null;
            try { shot = ScreenCapture.CaptureScreenshotAsTexture(); }
            catch (Exception e) { Debug.LogError("[Photo] Capture failed: " + e.Message); }

            for (int i = 0; i < count; i++)
            {
                if (hide[i] != null) hide[i].enabled = previous[i];
            }

            if (shot != null)
            {
                shot.wrapMode = TextureWrapMode.Clamp;
                if (lastPhoto != null) Destroy(lastPhoto);
                lastPhoto = shot;
                if (saveToDisk) TrySave(shot);
            }

            IsCapturing = false;
            onComplete?.Invoke(lastPhoto);
        }

        void TrySave(Texture2D tex)
        {
            try
            {
                string dir = Path.Combine(Application.persistentDataPath, folderName);
                Directory.CreateDirectory(dir);
                string path = Path.Combine(dir, "ChristmasAR_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png");
                File.WriteAllBytes(path, tex.EncodeToPNG());
                LastSavedPath = path;
                Debug.Log("[Photo] Saved " + path);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[Photo] Could not save photo: " + e.Message);
            }
        }

        void OnDestroy()
        {
            if (lastPhoto != null) Destroy(lastPhoto);
        }
    }
}
