using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace ChristmasAR
{
    /// <summary>
    /// Owns the live camera feed (WebCamTexture). Displays it full screen with cover-fit aspect and
    /// horizontal mirroring, and falls back to a generated simulated feed when no webcam is available.
    /// </summary>
    public class WebcamController : MonoBehaviour
    {
        [Header("Webcam")]
        [Tooltip("Forces the simulated camera background even if a webcam exists.")]
        [SerializeField] bool demoMode = false;
        [Tooltip("Optional: part of the device name to prefer. Empty = first front-facing / first device.")]
        [SerializeField] string preferredDeviceName = "";
        [SerializeField] int requestedWidth = 1280;
        [SerializeField] int requestedHeight = 720;
        [SerializeField] int requestedFps = 30;
        [Tooltip("Mirror like a selfie camera so movement feels natural.")]
        [SerializeField] bool mirrorHorizontally = true;
        [SerializeField] float startupTimeout = 5f;

        WebCamTexture webcam;
        Texture2D simulated;
        RawImage target;
        bool usingWebcam;

        Texture lastTexture;
        int lastW, lastH;
        Vector2 lastSize;

        public event Action<bool> Initialized;

        public bool DemoMode { get => demoMode; set => demoMode = value; }
        public bool IsLive => usingWebcam && webcam != null && webcam.isPlaying;
        public Texture CurrentTexture => IsLive ? (Texture)webcam : simulated;

        public void Bind(RawImage image)
        {
            target = image;
            lastTexture = null;
        }

        public void Initialize()
        {
            if (simulated == null) simulated = ProceduralArt.SimulatedCamera();
            StopAllCoroutines();
            StartCoroutine(InitRoutine());
        }

        IEnumerator InitRoutine()
        {
            if (demoMode) { UseSimulated("Demo Mode enabled - using simulated camera background."); yield break; }

            WebCamDevice[] devices = null;
            try { devices = WebCamTexture.devices; }
            catch (Exception e) { Debug.LogWarning("[Webcam] Could not enumerate devices: " + e.Message); }

            if (devices == null || devices.Length == 0) { UseSimulated("No webcam detected - using simulated camera background."); yield break; }

            string deviceName = devices[0].name;
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[i].isFrontFacing) { deviceName = devices[i].name; break; }
            }
            if (!string.IsNullOrEmpty(preferredDeviceName))
            {
                for (int i = 0; i < devices.Length; i++)
                {
                    if (devices[i].name.IndexOf(preferredDeviceName, StringComparison.OrdinalIgnoreCase) >= 0) { deviceName = devices[i].name; break; }
                }
            }

            try
            {
                webcam = new WebCamTexture(deviceName, requestedWidth, requestedHeight, requestedFps);
                webcam.Play();
            }
            catch (Exception e)
            {
                ReleaseWebcam();
                UseSimulated("Webcam failed to start (" + e.Message + ") - using simulated camera background.");
                yield break;
            }

            float elapsed = 0f;
            while (webcam != null && webcam.width <= 16 && elapsed < startupTimeout)
            {
                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }

            if (webcam == null || !webcam.isPlaying || webcam.width <= 16)
            {
                ReleaseWebcam();
                UseSimulated("Webcam did not deliver frames (it may be in use by another app) - using simulated camera background.");
                yield break;
            }

            usingWebcam = true;
            Debug.Log("[Webcam] Live camera started: " + deviceName + " (" + webcam.width + "x" + webcam.height + ")");
            Initialized?.Invoke(true);
        }

        void UseSimulated(string reason)
        {
            usingWebcam = false;
            Debug.Log("[Webcam] " + reason);
            Initialized?.Invoke(false);
        }

        void LateUpdate()
        {
            if (target == null) return;
            Texture tex = CurrentTexture;
            if (tex == null) return;

            Vector2 size = target.rectTransform.rect.size;
            if (tex == lastTexture && tex.width == lastW && tex.height == lastH && size == lastSize) return;
            lastTexture = tex;
            lastW = tex.width;
            lastH = tex.height;
            lastSize = size;
            Fit(tex, size);
        }

        /// <summary>Cover-fit: fill the screen, crop the overflow, keep aspect ratio, mirror if requested.</summary>
        void Fit(Texture tex, Vector2 size)
        {
            target.texture = tex;
            int angle = IsLive ? webcam.videoRotationAngle : 0;
            bool rotated = angle == 90 || angle == 270;

            float texAspect = rotated ? (float)tex.height / tex.width : (float)tex.width / tex.height;
            float viewAspect = size.y > 0f ? size.x / size.y : 1f;
            float w = 1f, h = 1f;
            if (texAspect > viewAspect) w = viewAspect / texAspect;
            else h = texAspect / viewAspect;
            if (rotated) { float tmp = w; w = h; h = tmp; }

            var r = new Rect((1f - w) * 0.5f, (1f - h) * 0.5f, w, h);
            if (mirrorHorizontally) { r.x += r.width; r.width = -r.width; }
            if (IsLive && webcam.videoVerticallyMirrored) { r.y += r.height; r.height = -r.height; }
            target.uvRect = r;
            target.rectTransform.localEulerAngles = new Vector3(0f, 0f, -angle);
        }

        void ReleaseWebcam()
        {
            if (webcam != null)
            {
                if (webcam.isPlaying) webcam.Stop();
                Destroy(webcam);
                webcam = null;
            }
            usingWebcam = false;
        }

        void OnDestroy()
        {
            ReleaseWebcam();
            if (simulated != null) Destroy(simulated);
        }
    }
}
