using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace ChristmasAR
{
    public enum Shortcut { Space, TakePhoto, Home, Sms, Email, Back, Backspace, Submit }

    /// <summary>Keyboard fallback that works with the new Input System, the legacy Input Manager, or both.</summary>
    public static class InputShortcuts
    {
#if ENABLE_INPUT_SYSTEM
        static readonly Key[] DigitKeys =
        {
            Key.Digit0, Key.Digit1, Key.Digit2, Key.Digit3, Key.Digit4,
            Key.Digit5, Key.Digit6, Key.Digit7, Key.Digit8, Key.Digit9
        };
        static readonly Key[] NumpadKeys =
        {
            Key.Numpad0, Key.Numpad1, Key.Numpad2, Key.Numpad3, Key.Numpad4,
            Key.Numpad5, Key.Numpad6, Key.Numpad7, Key.Numpad8, Key.Numpad9
        };
#endif

        public static bool Pressed(Shortcut shortcut)
        {
#if ENABLE_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb == null) return false;
            switch (shortcut)
            {
                case Shortcut.Space: return kb.spaceKey.wasPressedThisFrame;
                case Shortcut.TakePhoto: return kb.pKey.wasPressedThisFrame;
                case Shortcut.Home: return kb.hKey.wasPressedThisFrame;
                case Shortcut.Sms: return kb.sKey.wasPressedThisFrame;
                case Shortcut.Email: return kb.eKey.wasPressedThisFrame;
                case Shortcut.Back: return kb.escapeKey.wasPressedThisFrame;
                case Shortcut.Backspace: return kb.backspaceKey.wasPressedThisFrame;
                case Shortcut.Submit: return kb.enterKey.wasPressedThisFrame || kb.numpadEnterKey.wasPressedThisFrame;
            }
            return false;
#elif ENABLE_LEGACY_INPUT_MANAGER
            switch (shortcut)
            {
                case Shortcut.Space: return Input.GetKeyDown(KeyCode.Space);
                case Shortcut.TakePhoto: return Input.GetKeyDown(KeyCode.P);
                case Shortcut.Home: return Input.GetKeyDown(KeyCode.H);
                case Shortcut.Sms: return Input.GetKeyDown(KeyCode.S);
                case Shortcut.Email: return Input.GetKeyDown(KeyCode.E);
                case Shortcut.Back: return Input.GetKeyDown(KeyCode.Escape);
                case Shortcut.Backspace: return Input.GetKeyDown(KeyCode.Backspace);
                case Shortcut.Submit: return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
            }
            return false;
#else
            return false;
#endif
        }

        /// <summary>Returns the digit pressed this frame (0-9), or -1.</summary>
        public static int DigitPressed()
        {
#if ENABLE_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb == null) return -1;
            for (int i = 0; i < 10; i++)
            {
                if (kb[DigitKeys[i]].wasPressedThisFrame || kb[NumpadKeys[i]].wasPressedThisFrame) return i;
            }
            return -1;
#elif ENABLE_LEGACY_INPUT_MANAGER
            for (int i = 0; i < 10; i++)
            {
                if (Input.GetKeyDown(KeyCode.Alpha0 + i) || Input.GetKeyDown(KeyCode.Keypad0 + i)) return i;
            }
            return -1;
#else
            return -1;
#endif
        }
    }
}
