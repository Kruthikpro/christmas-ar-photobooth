using System;
using UnityEngine;

namespace ChristmasAR
{
    [Serializable]
    public struct SantaPose
    {
        [Tooltip("Screen position of Santa's centre (0-1 viewport coordinates).")]
        public Vector2 viewport;
        [Tooltip("Distance from the camera in metres. Larger = smaller on screen.")]
        public float depth;
        [Tooltip("Extra yaw so Santa can turn slightly towards the user.")]
        public float yaw;
        public float scale;
    }

    /// <summary>
    /// AR anchoring layer. In this Windows prototype the "anchor" is a configurable viewport position
    /// (a stable stand-in for body tracking). To upgrade to AR Foundation, replace ComputePose() with a
    /// pose from an ARAnchor / human body tracking - nothing else in the flow needs to change.
    /// </summary>
    public class ARCameraController : MonoBehaviour
    {
        [SerializeField] Camera arCamera;
        [SerializeField] SantaController santa;

        [Header("Camera")]
        [SerializeField] float fieldOfView = 50f;

        [Header("Santa anchors")]
        [Tooltip("Global Santa scale multiplier - quick fix for different camera distances.")]
        [SerializeField] float santaScale = 1f;
        [SerializeField] SantaPose besideUserPose = new SantaPose { viewport = new Vector2(0.70f, 0.42f), depth = 4f, yaw = -18f, scale = 1f };
        [SerializeField] SantaPose greetingPose = new SantaPose { viewport = new Vector2(0.5f, 0.47f), depth = 7.2f, yaw = 0f, scale = 1f };
        [SerializeField] SantaPose cornerPose = new SantaPose { viewport = new Vector2(0.5f, 0.88f), depth = 12f, yaw = 0f, scale = 1f };
        [SerializeField] float followSharpness = 7f;

        SantaMode mode = SantaMode.Hidden;

        public Camera Camera => arCamera;
        public float GreetingViewportY => greetingPose.viewport.y;
        public SantaMode Mode => mode;

        public void Initialize(Camera cam, SantaController santaController)
        {
            if (arCamera == null) arCamera = cam;
            if (santa == null) santa = santaController;
            if (arCamera != null)
            {
                arCamera.fieldOfView = fieldOfView;
                if (arCamera.farClipPlane < 120f) arCamera.farClipPlane = 120f;
                arCamera.clearFlags = CameraClearFlags.SolidColor;
                arCamera.backgroundColor = new Color(0.08f, 0f, 0.02f);
            }
            else Debug.LogError("[AR] No camera assigned to ARCameraController.");
        }

        public void SetMode(SantaMode newMode)
        {
            if (santa == null || arCamera == null) return;
            bool wasHidden = mode == SantaMode.Hidden || !santa.IsVisible;
            mode = newMode;
            if (newMode == SantaMode.Hidden) { santa.SetVisible(false); return; }

            if (wasHidden)
            {
                ComputePose(newMode, out var pos, out var rot, out float scale);
                santa.transform.SetPositionAndRotation(pos, rot);
                santa.transform.localScale = Vector3.one * scale;
            }
            santa.SetVisible(true);
        }

        void LateUpdate()
        {
            if (mode == SantaMode.Hidden || santa == null || arCamera == null) return;
            ComputePose(mode, out var pos, out var rot, out float scale);
            float k = 1f - Mathf.Exp(-followSharpness * Time.deltaTime);
            var t = santa.transform;
            t.SetPositionAndRotation(Vector3.Lerp(t.position, pos, k), Quaternion.Slerp(t.rotation, rot, k));
            t.localScale = Vector3.Lerp(t.localScale, Vector3.one * scale, k);
        }

        void ComputePose(SantaMode m, out Vector3 pos, out Quaternion rot, out float scale)
        {
            SantaPose p = m == SantaMode.Greeting ? greetingPose : (m == SantaMode.Corner ? cornerPose : besideUserPose);
            scale = Mathf.Max(0.01f, p.scale * santaScale);
            Vector3 center = arCamera.ViewportToWorldPoint(new Vector3(p.viewport.x, p.viewport.y, p.depth));
            pos = center - arCamera.transform.up * (santa.CenterHeight * scale);

            Vector3 toSanta = center - arCamera.transform.position;
            toSanta.y = 0f;
            if (toSanta.sqrMagnitude < 1e-4f) toSanta = Vector3.forward;
            // Santa's front is -Z, so pointing +Z away from the camera makes him face it.
            rot = Quaternion.LookRotation(toSanta.normalized, Vector3.up) * Quaternion.Euler(0f, p.yaw, 0f);
        }
    }
}
