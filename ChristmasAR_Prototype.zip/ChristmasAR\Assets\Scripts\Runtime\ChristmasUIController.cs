using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ChristmasAR
{
    /// <summary>
    /// Builds and drives every screen of the installation. Pure presentation: it raises UIAction events
    /// and never changes application state itself.
    ///
    /// Layering (back to front):
    ///   Background canvas (screen-space camera, far plane): webcam feed + festive red background + greeting circle
    ///   3D Santa (rendered by the AR camera in front of the background canvas)
    ///   Frame canvas (overlay): snow + Christmas photo frame/branding (included in captured photos)
    ///   UI canvas (overlay): buttons, text, keypad, popups (hidden during capture)
    /// </summary>
    public class ChristmasUIController : MonoBehaviour
    {
        [Header("Layout")]
        [SerializeField] Vector2 referenceResolution = new Vector2(1080f, 1920f);
        [SerializeField] float backgroundPlaneDistance = 60f;
        [SerializeField] float greetingCircleSize = 820f;
        [SerializeField] float transitionDuration = 0.45f;

        [Header("Copy")]
        [SerializeField] string arCaption = "Santa is here!  Strike a pose";
        [SerializeField] string brandingTitle = "Merry Christmas";

        public event Action<UIAction> ActionInvoked;
        public event Action<char> KeypadPressed;

        public RawImage WebcamImage { get; private set; }
        public bool IsBuilt { get; private set; }
        public bool IsQrOpen => qrPopup != null && qrPopup.target > 0.5f;
        public bool IsTypingEmail => emailField != null && emailField.isFocused;
        public Canvas[] CaptureHiddenCanvases { get; private set; }

        class Fade
        {
            public CanvasGroup group;
            public float target;
            public bool scale;
        }

        readonly List<Fade> fades = new List<Fade>();
        Fade[] screens;
        Fade arScreen, homeScreen, homeIntro, homeStart, merryScreen, captureScreen, shareScreen, keypadScreen, emailScreen, confirmScreen;
        Fade festive, greetingCircle, photoFrame, qrPopup;

        Canvas bgCanvas, frameCanvas, uiCanvas;
        Text countdownText, keypadDisplay, keypadHint, confirmTitle, confirmBody, emailError;
        RawImage photoPreview, qrImage;
        AspectRatioFitter photoFitter;
        InputField emailField;
        Image flash;
        float flashAlpha, countdownPunch;

        static readonly Vector2 Center = new Vector2(0.5f, 0.5f);

        // ---------------------------------------------------------------- build

        public void Build(Camera cam, float greetingViewportY, ParticleController particles)
        {
            if (IsBuilt) return;
            IsBuilt = true;
            EnsureEventSystem();

            bgCanvas = MakeCanvas("Background Canvas", RenderMode.ScreenSpaceCamera, 0, cam, false);
            frameCanvas = MakeCanvas("AR Frame Canvas", RenderMode.ScreenSpaceOverlay, 5, null, false);
            uiCanvas = MakeCanvas("UI Canvas", RenderMode.ScreenSpaceOverlay, 10, null, true);
            CaptureHiddenCanvases = new[] { uiCanvas };

            BuildBackground((RectTransform)bgCanvas.transform, greetingViewportY, particles);
            BuildFrame((RectTransform)frameCanvas.transform, particles);

            var ui = (RectTransform)uiCanvas.transform;
            BuildArScreen(ui);
            BuildHomeScreen(ui);
            BuildMerryScreen(ui, greetingViewportY);
            BuildCaptureScreen(ui);
            BuildShareScreen(ui);
            BuildKeypadScreen(ui);
            BuildEmailScreen(ui);
            BuildConfirmScreen(ui);
            BuildQrPopup(ui);

            flash = UIFactory.MakeImage("Flash", ui, null, new Color(1f, 1f, 1f, 0f));
            UIFactory.Stretch(flash.rectTransform);

            screens = new[] { arScreen, homeScreen, merryScreen, captureScreen, shareScreen, keypadScreen, emailScreen, confirmScreen };
        }

        void EnsureEventSystem()
        {
            if (EventSystem.current != null || FindAnyObjectByType<EventSystem>() != null) return;
            var go = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            var module = go.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
            module.AssignDefaultActions();
#else
            go.AddComponent<StandaloneInputModule>();
#endif
        }

        Canvas MakeCanvas(string name, RenderMode mode, int order, Camera cam, bool interactive)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5;
            go.transform.SetParent(transform, false);
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = mode;
            canvas.sortingOrder = order;
            if (mode == RenderMode.ScreenSpaceCamera)
            {
                canvas.worldCamera = cam;
                canvas.planeDistance = backgroundPlaneDistance;
                if (cam == null) canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            }
            var scaler = go.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = referenceResolution;
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 1f; // portrait layout: keep height constant, centre horizontally
            if (interactive) go.AddComponent<GraphicRaycaster>();
            return canvas;
        }

        Fade Register(CanvasGroup g, bool scale, bool visible)
        {
            var f = new Fade { group = g, scale = scale, target = visible ? 1f : 0f };
            g.alpha = f.target;
            g.interactable = visible;
            g.blocksRaycasts = visible;
            fades.Add(f);
            return f;
        }

        Fade NewGroup(string name, Transform parent, bool scale, bool visible)
        {
            var rt = UIFactory.Stretch(UIFactory.MakeRect(name, parent));
            return Register(rt.gameObject.AddComponent<CanvasGroup>(), scale, visible);
        }

        Button Btn(Transform parent, string label, Vector2 pos, Vector2 size, int fontSize, UIAction action, bool pulse = false)
        {
            return UIFactory.MakeButton(label, parent, label, Center, pos, size, fontSize, () => ActionInvoked?.Invoke(action), pulse);
        }

        Text Title(Transform parent, string content, Vector2 pos, int size, FontStyle style = FontStyle.Bold)
        {
            var t = UIFactory.MakeText(content, parent, content, size, Color.white, TextAnchor.MiddleCenter, style);
            UIFactory.Place(t.rectTransform, Center, pos, new Vector2(1000f, size * 2.6f));
            UIFactory.AddShadow(t);
            return t;
        }

        void BuildBackground(RectTransform root, float greetingY, ParticleController particles)
        {
            WebcamImage = UIFactory.MakeRaw("Webcam Feed", root, null, Color.white);
            UIFactory.Stretch(WebcamImage.rectTransform);

            festive = NewGroup("Festive Background", root, false, false);
            if (particles != null) particles.BuildFestiveBackground((RectTransform)festive.group.transform);

            greetingCircle = NewGroup("Greeting Circle", root, true, false);
            var circleRoot = UIFactory.MakeRect("Circle", greetingCircle.group.transform);
            circleRoot.anchorMin = circleRoot.anchorMax = new Vector2(0.5f, greetingY);
            circleRoot.sizeDelta = new Vector2(greetingCircleSize, greetingCircleSize);
            circleRoot.anchoredPosition = Vector2.zero;
            var glow = UIFactory.MakeImage("Glow", circleRoot, UIFactory.SoftCircle, new Color(1f, 0.8f, 0.45f, 0.45f));
            UIFactory.Place(glow.rectTransform, Center, Vector2.zero, Vector2.one * greetingCircleSize * 1.45f);
            var disc = UIFactory.MakeImage("Disc", circleRoot, UIFactory.Circle, new Color(0.98f, 0.93f, 0.90f, 1f));
            UIFactory.Stretch(disc.rectTransform, 10f);
            var inner = UIFactory.MakeImage("InnerGlow", circleRoot, UIFactory.SoftCircle, new Color(1f, 1f, 1f, 0.9f));
            UIFactory.Stretch(inner.rectTransform, 40f);
            var ring = UIFactory.MakeImage("Ring", circleRoot, UIFactory.Ring, UIFactory.Gold);
            UIFactory.Stretch(ring.rectTransform);
        }

        void BuildFrame(RectTransform root, ParticleController particles)
        {
            photoFrame = NewGroup("Photo Frame", root, false, false);
            var fr = photoFrame.group.transform;

            var border = UIFactory.MakeImage("Border", fr, UIFactory.RoundedOutline, new Color(1f, 0.85f, 0.5f, 0.9f));
            UIFactory.Stretch(border.rectTransform, 26f);
            var border2 = UIFactory.MakeImage("BorderInner", fr, UIFactory.RoundedOutline, new Color(1f, 1f, 1f, 0.45f));
            UIFactory.Stretch(border2.rectTransform, 40f);

            var banner = UIFactory.Place(UIFactory.MakeRect("Banner", fr), new Vector2(0.5f, 0f), new Vector2(0f, 150f), new Vector2(760f, 160f));
            var bannerFill = UIFactory.MakeImage("Fill", banner, UIFactory.RoundedFill, new Color(0.55f, 0.02f, 0.06f, 0.85f));
            UIFactory.Stretch(bannerFill.rectTransform);
            var bannerBorder = UIFactory.MakeImage("Border", banner, UIFactory.RoundedOutline, UIFactory.Gold);
            UIFactory.Stretch(bannerBorder.rectTransform);
            var title = UIFactory.MakeText("Title", banner, brandingTitle, 70, Color.white, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            UIFactory.Place(title.rectTransform, Center, new Vector2(0f, 18f), new Vector2(740f, 90f));
            UIFactory.AddShadow(title);
            var sub = UIFactory.MakeText("Sub", banner, DateTime.Now.Year + "  •  AR PHOTO EXPERIENCE", 28, UIFactory.Gold);
            UIFactory.Place(sub.rectTransform, Center, new Vector2(0f, -45f), new Vector2(740f, 40f));

            if (particles != null) particles.BuildSnow(root);
        }

        void BuildArScreen(RectTransform ui)
        {
            arScreen = NewGroup("Screen_AR", ui, false, false);
            var s = arScreen.group.transform;

            var caption = UIFactory.MakeText("Caption", s, arCaption, 60, Color.white, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            UIFactory.Place(caption.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -190f), new Vector2(1000f, 100f));
            UIFactory.AddShadow(caption, 3f, 0.8f);

            UIFactory.MakeButton("HOME", s, "HOME", new Vector2(0f, 1f), new Vector2(180f, -95f), new Vector2(240f, 90f), 40,
                () => ActionInvoked?.Invoke(UIAction.Home));
            UIFactory.MakeButton("TAKE PHOTO", s, "TAKE PHOTO", new Vector2(0.5f, 0f), new Vector2(0f, 380f), new Vector2(480f, 120f), 52,
                () => ActionInvoked?.Invoke(UIAction.TakePhoto), true);
        }

        void BuildHomeScreen(RectTransform ui)
        {
            homeScreen = NewGroup("Screen_Home", ui, true, false);
            var s = homeScreen.group.transform;

            homeIntro = NewGroup("Intro", s, true, false);
            Title(homeIntro.group.transform, "MERRY CHRISTMAS", new Vector2(0f, 60f), 110, FontStyle.BoldAndItalic);

            homeStart = NewGroup("Start", s, true, false);
            var st = homeStart.group.transform;
            Btn(st, "TOUCH TO START", new Vector2(0f, -120f), new Vector2(800f, 210f), 86, UIAction.Start, true);
            var hint = UIFactory.MakeText("Hint", st, "Step into the magic of Christmas", 40, new Color(1f, 1f, 1f, 0.85f), TextAnchor.MiddleCenter, FontStyle.Italic);
            UIFactory.Place(hint.rectTransform, Center, new Vector2(0f, -300f), new Vector2(1000f, 60f));
        }

        void BuildMerryScreen(RectTransform ui, float greetingY)
        {
            merryScreen = NewGroup("Screen_Merry", ui, true, false);
            var s = merryScreen.group.transform;
            Btn(s, "HOME", new Vector2(0f, 820f), new Vector2(300f, 100f), 46, UIAction.Home);
            var title = UIFactory.MakeText("Merry Christmas", s, "Merry\nChristmas", 150, Color.white, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            title.lineSpacing = 0.85f;
            float circleTop = (greetingY - 0.5f) * referenceResolution.y + greetingCircleSize * 0.5f;
            UIFactory.Place(title.rectTransform, Center, new Vector2(0f, Mathf.Min(620f, circleTop + 200f)), new Vector2(1000f, 320f));
            UIFactory.AddShadow(title, 5f, 0.6f);
            title.gameObject.AddComponent<Outline>().effectColor = new Color(1f, 0.8f, 0.4f, 0.35f);
            Btn(s, "TAKE PHOTO", new Vector2(0f, -640f), new Vector2(560f, 140f), 60, UIAction.TakePhoto, true);
        }

        void BuildCaptureScreen(RectTransform ui)
        {
            captureScreen = NewGroup("Screen_Capture", ui, false, false);
            var s = captureScreen.group.transform;
            var ready = UIFactory.MakeText("Ready", s, "Get ready!", 64, Color.white, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            UIFactory.Place(ready.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -190f), new Vector2(1000f, 100f));
            UIFactory.AddShadow(ready, 3f, 0.8f);
            countdownText = UIFactory.MakeText("Countdown", s, "", 340, Color.white);
            UIFactory.Place(countdownText.rectTransform, Center, Vector2.zero, new Vector2(600f, 600f));
            UIFactory.AddShadow(countdownText, 8f, 0.7f);
            countdownText.gameObject.AddComponent<Outline>().effectColor = new Color(0.8f, 0.05f, 0.1f, 0.8f);
        }

        void BuildShareScreen(RectTransform ui)
        {
            shareScreen = NewGroup("Screen_Share", ui, true, false);
            var s = shareScreen.group.transform;
            Title(s, "Your Christmas Photo", new Vector2(0f, 820f), 70, FontStyle.BoldAndItalic);

            var holder = UIFactory.Place(UIFactory.MakeRect("PhotoHolder", s), Center, new Vector2(0f, 360f), new Vector2(860f, 720f));
            photoPreview = UIFactory.MakeRaw("Photo", holder, null, Color.white);
            UIFactory.Stretch(photoPreview.rectTransform);
            photoFitter = photoPreview.gameObject.AddComponent<AspectRatioFitter>();
            photoFitter.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
            photoFitter.aspectRatio = 16f / 9f;
            var pf = UIFactory.MakeImage("Frame", photoPreview.rectTransform, UIFactory.RoundedOutline, UIFactory.Gold);
            UIFactory.Stretch(pf.rectTransform, -12f);

            Btn(s, "EMAIL", new Vector2(0f, -120f), new Vector2(540f, 115f), 52, UIAction.Email);
            Btn(s, "SMS", new Vector2(0f, -260f), new Vector2(540f, 115f), 52, UIAction.Sms);
            Btn(s, "QR CODE", new Vector2(0f, -400f), new Vector2(540f, 115f), 52, UIAction.Qr);
            Btn(s, "RETAKE", new Vector2(-210f, -620f), new Vector2(380f, 110f), 46, UIAction.Retake);
            Btn(s, "HOME", new Vector2(210f, -620f), new Vector2(380f, 110f), 46, UIAction.Home);
        }

        void BuildKeypadScreen(RectTransform ui)
        {
            keypadScreen = NewGroup("Screen_Keypad", ui, true, false);
            var s = keypadScreen.group.transform;
            Title(s, "Enter your mobile number", new Vector2(0f, 470f), 54);

            var display = UIFactory.Place(UIFactory.MakeRect("Display", s), Center, new Vector2(0f, 340f), new Vector2(820f, 130f));
            var df = UIFactory.MakeImage("Fill", display, UIFactory.RoundedFill, new Color(0.25f, 0f, 0.03f, 0.75f));
            UIFactory.Stretch(df.rectTransform);
            var db = UIFactory.MakeImage("Border", display, UIFactory.RoundedOutline, Color.white);
            UIFactory.Stretch(db.rectTransform);
            keypadDisplay = UIFactory.MakeText("Number", display, "", 70, Color.white);
            UIFactory.Stretch(keypadDisplay.rectTransform);
            keypadHint = UIFactory.MakeText("Hint", display, "", 40, new Color(1f, 1f, 1f, 0.5f), TextAnchor.MiddleCenter, FontStyle.Italic);
            UIFactory.Stretch(keypadHint.rectTransform);

            string keys = "123456789*0#";
            for (int i = 0; i < keys.Length; i++)
            {
                char c = keys[i];
                int col = i % 3, row = i / 3;
                var pos = new Vector2((col - 1) * 235f, 160f - row * 155f);
                UIFactory.MakeButton("Key " + c, s, c.ToString(), Center, pos, new Vector2(205f, 130f), 72, () => KeypadPressed?.Invoke(c));
            }

            Btn(s, "BACK", new Vector2(-235f, -500f), new Vector2(350f, 115f), 50, UIAction.KeypadBack);
            Btn(s, "SEND", new Vector2(235f, -500f), new Vector2(350f, 115f), 50, UIAction.Send, true);
            Btn(s, "HOME", new Vector2(0f, -660f), new Vector2(350f, 105f), 46, UIAction.Home);
        }

        void BuildEmailScreen(RectTransform ui)
        {
            emailScreen = NewGroup("Screen_Email", ui, true, false);
            var s = emailScreen.group.transform;
            Title(s, "Enter your email address", new Vector2(0f, 470f), 54);

            var root = UIFactory.Place(UIFactory.MakeRect("EmailField", s), Center, new Vector2(0f, 300f), new Vector2(880f, 130f));
            root.gameObject.SetActive(false); // configure InputField fully before it enables
            var bg = root.gameObject.AddComponent<Image>();
            bg.sprite = UIFactory.RoundedFill;
            bg.type = Image.Type.Sliced;
            bg.color = new Color(1f, 1f, 1f, 0.96f);
            var text = UIFactory.MakeText("Text", root, "", 50, UIFactory.DarkRed, TextAnchor.MiddleLeft, FontStyle.Normal);
            UIFactory.Stretch(text.rectTransform);
            text.rectTransform.offsetMin = new Vector2(36f, 8f);
            text.rectTransform.offsetMax = new Vector2(-36f, -8f);
            text.supportRichText = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            var placeholder = UIFactory.MakeText("Placeholder", root, "name@email.com", 50, new Color(0.5f, 0.2f, 0.2f, 0.45f), TextAnchor.MiddleLeft, FontStyle.Italic);
            UIFactory.Stretch(placeholder.rectTransform);
            placeholder.rectTransform.offsetMin = new Vector2(36f, 8f);
            placeholder.rectTransform.offsetMax = new Vector2(-36f, -8f);
            emailField = root.gameObject.AddComponent<InputField>();
            emailField.textComponent = text;
            emailField.placeholder = placeholder;
            emailField.targetGraphic = bg;
            emailField.contentType = InputField.ContentType.EmailAddress;
            emailField.lineType = InputField.LineType.SingleLine;
            emailField.characterLimit = 64;
            emailField.customCaretColor = true;
            emailField.caretColor = UIFactory.Red;
            root.gameObject.SetActive(true);

            emailError = UIFactory.MakeText("Error", s, "", 38, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.Italic);
            UIFactory.Place(emailError.rectTransform, Center, new Vector2(0f, 180f), new Vector2(1000f, 60f));

            Btn(s, "BACK", new Vector2(-235f, 20f), new Vector2(350f, 115f), 50, UIAction.Back);
            Btn(s, "SEND", new Vector2(235f, 20f), new Vector2(350f, 115f), 50, UIAction.Send, true);
            Btn(s, "HOME", new Vector2(0f, -150f), new Vector2(350f, 105f), 46, UIAction.Home);
        }

        void BuildConfirmScreen(RectTransform ui)
        {
            confirmScreen = NewGroup("Screen_Confirm", ui, true, false);
            var s = confirmScreen.group.transform;

            var badge = UIFactory.Place(UIFactory.MakeRect("Badge", s), Center, new Vector2(0f, 230f), new Vector2(300f, 300f));
            var glow = UIFactory.MakeImage("Glow", badge, UIFactory.SoftCircle, new Color(1f, 0.8f, 0.45f, 0.5f));
            UIFactory.Place(glow.rectTransform, Center, Vector2.zero, new Vector2(520f, 520f));
            var disc = UIFactory.MakeImage("Disc", badge, UIFactory.Circle, new Color(0.55f, 0.02f, 0.06f, 0.9f));
            UIFactory.Stretch(disc.rectTransform);
            var ring = UIFactory.MakeImage("Ring", badge, UIFactory.Ring, Color.white);
            UIFactory.Stretch(ring.rectTransform);
            var tick1 = UIFactory.MakeImage("Tick1", badge, null, UIFactory.Gold);
            UIFactory.Place(tick1.rectTransform, Center, new Vector2(-47f, -22f), new Vector2(70f, 24f)).localRotation = Quaternion.Euler(0f, 0f, -45f);
            var tick2 = UIFactory.MakeImage("Tick2", badge, null, UIFactory.Gold);
            UIFactory.Place(tick2.rectTransform, Center, new Vector2(22f, 8f), new Vector2(150f, 24f)).localRotation = Quaternion.Euler(0f, 0f, 45f);

            confirmTitle = Title(s, "Sent!", new Vector2(0f, -20f), 100, FontStyle.BoldAndItalic);
            confirmBody = UIFactory.MakeText("Body", s, "", 44, Color.white, TextAnchor.MiddleCenter, FontStyle.Normal);
            UIFactory.Place(confirmBody.rectTransform, Center, new Vector2(0f, -190f), new Vector2(1000f, 160f));
            var thanks = UIFactory.MakeText("Thanks", s, "Thank you & Happy Holidays!", 46, UIFactory.Gold, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            UIFactory.Place(thanks.rectTransform, Center, new Vector2(0f, -340f), new Vector2(1000f, 70f));
            Btn(s, "HOME", new Vector2(0f, -560f), new Vector2(380f, 115f), 50, UIAction.Home, true);
        }

        void BuildQrPopup(RectTransform ui)
        {
            qrPopup = NewGroup("QR Popup", ui, true, false);
            var s = qrPopup.group.transform;
            var scrim = UIFactory.MakeImage("Scrim", s, null, new Color(0.1f, 0f, 0.02f, 0.8f));
            UIFactory.Stretch(scrim.rectTransform, -2000f);
            scrim.raycastTarget = true;

            var panel = UIFactory.Place(UIFactory.MakeRect("Panel", s), Center, new Vector2(0f, 40f), new Vector2(760f, 1080f));
            var pfill = UIFactory.MakeImage("Fill", panel, UIFactory.RoundedFill, new Color(0.62f, 0.03f, 0.08f, 0.97f));
            UIFactory.Stretch(pfill.rectTransform);
            var pborder = UIFactory.MakeImage("Border", panel, UIFactory.RoundedOutline, UIFactory.Gold);
            UIFactory.Stretch(pborder.rectTransform);

            var t = UIFactory.MakeText("Title", panel, "Scan to download\nyour photo", 56, Color.white, TextAnchor.MiddleCenter, FontStyle.BoldAndItalic);
            UIFactory.Place(t.rectTransform, Center, new Vector2(0f, 400f), new Vector2(740f, 160f));
            var qrBg = UIFactory.MakeImage("QrBg", panel, UIFactory.RoundedFill, Color.white);
            UIFactory.Place(qrBg.rectTransform, Center, new Vector2(0f, 0f), new Vector2(580f, 580f));
            qrImage = UIFactory.MakeRaw("QR", qrBg.rectTransform, null, Color.white);
            UIFactory.Stretch(qrImage.rectTransform, 20f);
            UIFactory.MakeButton("CLOSE", panel, "CLOSE", Center, new Vector2(0f, -410f), new Vector2(360f, 110f), 48,
                () => ActionInvoked?.Invoke(UIAction.CloseQr));
        }

        // ---------------------------------------------------------------- state presentation

        public void ShowState(AppState state)
        {
            if (!IsBuilt) return;
            Fade screen = null;
            bool showFestive = true, showFrame = false, showCircle = false, intro = false, start = false;
            switch (state)
            {
                case AppState.AR_CAMERA: screen = arScreen; showFestive = false; showFrame = true; break;
                case AppState.CHRISTMAS_HOME: screen = homeScreen; intro = true; break;
                case AppState.TOUCH_TO_START: screen = homeScreen; start = true; break;
                case AppState.RETURN_HOME: screen = homeScreen; intro = true; break;
                case AppState.MERRY_CHRISTMAS: screen = merryScreen; showCircle = true; break;
                case AppState.PHOTO_CAPTURE: screen = captureScreen; showFestive = false; showFrame = true; break;
                case AppState.SHARE_MENU: screen = shareScreen; break;
                case AppState.PHONE_KEYPAD: screen = keypadScreen; break;
                case AppState.EMAIL_ENTRY: screen = emailScreen; break;
                case AppState.SEND_CONFIRMATION: screen = confirmScreen; break;
            }

            for (int i = 0; i < screens.Length; i++) SetTarget(screens[i], screens[i] == screen);
            SetTarget(homeIntro, intro);
            SetTarget(homeStart, start);
            SetTarget(festive, showFestive);
            SetTarget(photoFrame, showFrame);
            SetTarget(greetingCircle, showCircle);
            if (state != AppState.SHARE_MENU) SetTarget(qrPopup, false);
            if (state != AppState.PHOTO_CAPTURE) SetCountdown("");

            var es = EventSystem.current;
            if (es != null && state != AppState.EMAIL_ENTRY) es.SetSelectedGameObject(null);
        }

        static void SetTarget(Fade f, bool on)
        {
            if (f == null) return;
            f.target = on ? 1f : 0f;
            f.group.interactable = on;
            f.group.blocksRaycasts = on;
        }

        public void SetCountdown(string value)
        {
            if (countdownText == null) return;
            countdownText.text = value;
            if (!string.IsNullOrEmpty(value)) countdownPunch = 1f;
        }

        public void Flash() { flashAlpha = 1f; }

        public void SetPhoto(Texture2D photo)
        {
            if (photoPreview == null) return;
            photoPreview.texture = photo;
            if (photo != null && photo.height > 0) photoFitter.aspectRatio = (float)photo.width / photo.height;
        }

        public void SetQrTexture(Texture tex)
        {
            if (qrImage != null) qrImage.texture = tex;
        }

        public void ShowQr(bool show) { SetTarget(qrPopup, show); }

        public void SetKeypadDisplay(string number, bool canSend)
        {
            if (keypadDisplay == null) return;
            keypadDisplay.text = number;
            keypadHint.text = string.IsNullOrEmpty(number) ? "Tap the numbers below" : "";
            keypadDisplay.color = canSend ? Color.white : new Color(1f, 1f, 1f, 0.8f);
        }

        public void ShowKeypadError(string message)
        {
            if (keypadHint == null || keypadDisplay == null) return;
            if (string.IsNullOrEmpty(keypadDisplay.text)) keypadHint.text = message;
            countdownPunch = 0f;
        }

        public void ResetEmail()
        {
            if (emailField == null) return;
            emailField.text = "";
            emailError.text = "";
        }

        public void FocusEmail()
        {
            if (emailField == null) return;
            emailField.Select();
            emailField.ActivateInputField();
        }

        public string EmailText => emailField != null ? emailField.text : "";

        public void SetEmailError(string message)
        {
            if (emailError != null) emailError.text = message;
        }

        public void ShowConfirmation(string title, string body)
        {
            if (confirmTitle != null) confirmTitle.text = title;
            if (confirmBody != null) confirmBody.text = body;
        }

        // ---------------------------------------------------------------- animation

        void Update()
        {
            if (!IsBuilt) return;
            float dt = Time.unscaledDeltaTime;
            float step = dt / Mathf.Max(0.01f, transitionDuration);
            for (int i = 0; i < fades.Count; i++)
            {
                var f = fades[i];
                float a = f.group.alpha;
                if (Mathf.Approximately(a, f.target)) continue;
                a = Mathf.MoveTowards(a, f.target, step);
                f.group.alpha = a;
                if (f.scale)
                {
                    float e = 1f - (1f - a) * (1f - a);
                    float s = Mathf.Lerp(0.94f, 1f, e);
                    f.group.transform.localScale = new Vector3(s, s, 1f);
                }
            }

            if (flash != null && (flashAlpha > 0f || flash.color.a > 0f))
            {
                flashAlpha = Mathf.MoveTowards(flashAlpha, 0f, dt * 2.2f);
                flash.color = new Color(1f, 1f, 1f, flashAlpha);
            }

            if (countdownText != null && countdownPunch > 0f)
            {
                countdownPunch = Mathf.MoveTowards(countdownPunch, 0f, dt * 2.5f);
                float s = 1f + countdownPunch * countdownPunch * 0.6f;
                countdownText.rectTransform.localScale = new Vector3(s, s, 1f);
                var c = countdownText.color;
                c.a = Mathf.Clamp01(0.4f + (1f - countdownPunch) * 1.2f);
                countdownText.color = c;
            }
        }
    }
}
