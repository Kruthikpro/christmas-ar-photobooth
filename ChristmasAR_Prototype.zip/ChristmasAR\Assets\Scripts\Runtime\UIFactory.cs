using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ChristmasAR
{
    /// <summary>Builds uGUI elements and procedural sprites at runtime, so the UI has no asset dependencies.</summary>
    public static class UIFactory
    {
        public static readonly Color Red = new Color(0.78f, 0.06f, 0.11f);
        public static readonly Color DarkRed = new Color(0.36f, 0.02f, 0.05f);
        public static readonly Color PanelRed = new Color(0.62f, 0.03f, 0.08f, 0.78f);
        public static readonly Color Gold = new Color(1f, 0.80f, 0.42f);

        static Font font;
        static Sprite roundedFill, roundedOutline, circle, softCircle, ring;

        public static Font DefaultFont
        {
            get
            {
                if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (font == null) font = Font.CreateDynamicFontFromOSFont(new[] { "Segoe UI", "Arial" }, 48);
                return font;
            }
        }

        public static Sprite RoundedFill { get { if (roundedFill == null) roundedFill = MakeRounded(96, 30f, 0f); return roundedFill; } }
        public static Sprite RoundedOutline { get { if (roundedOutline == null) roundedOutline = MakeRounded(96, 30f, 3f); return roundedOutline; } }
        public static Sprite Circle { get { if (circle == null) circle = MakeCircle(128, 0f, false); return circle; } }
        public static Sprite SoftCircle { get { if (softCircle == null) softCircle = MakeCircle(128, 0f, true); return softCircle; } }
        public static Sprite Ring { get { if (ring == null) ring = MakeCircle(256, 6f, false); return ring; } }

        static Texture2D NewTex(int size, string name)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.name = name;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            return tex;
        }

        static Sprite MakeRounded(int size, float radius, float thickness)
        {
            var tex = NewTex(size, thickness > 0f ? "RoundedOutline" : "RoundedFill");
            var px = new Color32[size * size];
            float half = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float qx = Mathf.Abs(x + 0.5f - half) - (half - radius - 1f);
                    float qy = Mathf.Abs(y + 0.5f - half) - (half - radius - 1f);
                    float outside = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude;
                    float d = outside + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                    float a = Mathf.Clamp01(0.5f - d);
                    if (thickness > 0f) a *= Mathf.Clamp01(d + thickness + 0.5f);
                    px[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            float b = radius + 2f;
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(b, b, b, b));
        }

        static Sprite MakeCircle(int size, float thickness, bool soft)
        {
            var tex = NewTex(size, soft ? "SoftCircle" : (thickness > 0f ? "Ring" : "Circle"));
            var px = new Color32[size * size];
            float c = size * 0.5f, r = c - 1f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x + 0.5f - c, dy = y + 0.5f - c;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    float a;
                    if (soft)
                    {
                        float t = 1f - Mathf.Clamp01(dist / r);
                        a = t * t;
                    }
                    else
                    {
                        float d = dist - r;
                        a = Mathf.Clamp01(0.5f - d);
                        if (thickness > 0f) a *= Mathf.Clamp01(d + thickness + 0.5f);
                    }
                    px[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }
            tex.SetPixels32(px);
            tex.Apply(false, true);
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
        }

        public static RectTransform MakeRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5; // UI
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        public static RectTransform Stretch(RectTransform rt, float inset = 0f)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(inset, inset);
            rt.offsetMax = new Vector2(-inset, -inset);
            return rt;
        }

        public static RectTransform Place(RectTransform rt, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        public static Image MakeImage(string name, Transform parent, Sprite sprite, Color color)
        {
            var img = MakeRect(name, parent).gameObject.AddComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            img.raycastTarget = false;
            if (sprite != null && sprite.border != Vector4.zero) img.type = Image.Type.Sliced;
            return img;
        }

        public static RawImage MakeRaw(string name, Transform parent, Texture texture, Color color)
        {
            var img = MakeRect(name, parent).gameObject.AddComponent<RawImage>();
            img.texture = texture;
            img.color = color;
            img.raycastTarget = false;
            return img;
        }

        public static Text MakeText(string name, Transform parent, string content, int size, Color color,
            TextAnchor anchor = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Bold)
        {
            var t = MakeRect(name, parent).gameObject.AddComponent<Text>();
            t.font = DefaultFont;
            t.text = content;
            t.fontSize = size;
            t.color = color;
            t.alignment = anchor;
            t.fontStyle = style;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        public static T AddShadow<T>(T graphic, float distance = 4f, float alpha = 0.55f) where T : Graphic
        {
            var s = graphic.gameObject.AddComponent<Shadow>();
            s.effectColor = new Color(0.15f, 0f, 0.02f, alpha);
            s.effectDistance = new Vector2(distance, -distance);
            return graphic;
        }

        /// <summary>Premium kiosk button: translucent red panel, thin white border, gold glow, hover/press animation.</summary>
        public static Button MakeButton(string name, Transform parent, string label, Vector2 anchor, Vector2 pos, Vector2 size,
            int fontSize, UnityAction onClick, bool pulse = false)
        {
            var root = Place(MakeRect(name, parent), anchor, pos, size);

            var glow = MakeImage("Glow", root, SoftCircle, new Color(Gold.r, Gold.g, Gold.b, 0f));
            Place(glow.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, size * 1.35f + new Vector2(80f, 80f));

            var fill = MakeImage("Fill", root, RoundedFill, PanelRed);
            Stretch(fill.rectTransform);
            fill.raycastTarget = true;

            var border = MakeImage("Border", root, RoundedOutline, new Color(1f, 1f, 1f, 0.95f));
            Stretch(border.rectTransform);

            var text = MakeText("Label", root, label, fontSize, Color.white);
            Stretch(text.rectTransform);
            AddShadow(text, 2f, 0.4f);

            var btn = root.gameObject.AddComponent<Button>();
            btn.targetGraphic = fill;
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.86f, 0.86f);
            colors.pressedColor = new Color(0.8f, 0.7f, 0.7f);
            colors.selectedColor = Color.white;
            colors.fadeDuration = 0.08f;
            btn.colors = colors;
            var nav = btn.navigation;
            nav.mode = Navigation.Mode.None;
            btn.navigation = nav;

            if (onClick != null) btn.onClick.AddListener(onClick);
            // Deselect so Space/Enter never re-submit the last clicked button (keyboard shortcuts are handled separately).
            btn.onClick.AddListener(Deselect);

            root.gameObject.AddComponent<UIButtonFx>().Setup(glow, pulse);
            return btn;
        }

        static void Deselect()
        {
            var es = EventSystem.current;
            if (es != null) es.SetSelectedGameObject(null);
        }
    }
}
