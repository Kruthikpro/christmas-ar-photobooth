using UnityEngine;

namespace ChristmasAR
{
    /// <summary>
    /// Sharing back-end for the prototype. Nothing is actually sent: SimulateSend() logs the request
    /// and returns confirmation copy. Swap this class for a real email/SMS service later.
    /// </summary>
    public class ShareController : MonoBehaviour
    {
        [SerializeField, Range(21, 41)] int qrModules = 29;

        Texture2D qr;

        public Texture2D QrTexture
        {
            get
            {
                if (qr == null) Regenerate(12345);
                return qr;
            }
        }

        /// <summary>Creates a fresh QR-style code (one per photo session).</summary>
        public void Regenerate(int seed)
        {
            if (qr != null) Destroy(qr);
            qr = ProceduralArt.QrStyle(qrModules, seed);
        }

        public static bool IsValidEmail(string s)
        {
            if (string.IsNullOrEmpty(s)) return false;
            s = s.Trim();
            int at = s.IndexOf('@');
            if (at <= 0 || at != s.LastIndexOf('@')) return false;
            int dot = s.IndexOf('.', at);
            return dot > at + 1 && dot < s.Length - 1 && s.IndexOf(' ') < 0;
        }

        public string SimulateSend(string channel, string destination)
        {
            Debug.Log("[Share] (prototype) " + channel + " delivery simulated to " + destination);
            return "Your Christmas photo is on its way to\n" + destination;
        }

        void OnDestroy()
        {
            if (qr != null) Destroy(qr);
        }
    }
}
