using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ChristmasAR
{
    /// <summary>
    /// Builds a stylised Santa from primitives (or instantiates a custom model) and animates him:
    /// idle breathing, body sway, head movement, periodic hand wave and a pop-in / pop-out.
    /// Positioning is NOT done here - ARCameraController owns the anchor transform.
    /// Santa's front faces local -Z.
    /// </summary>
    public class SantaController : MonoBehaviour
    {
        [Header("Model")]
        [Tooltip("Lit material used as the base for all Santa colours (created by the setup menu).")]
        [SerializeField] Material baseMaterial;
        [Tooltip("Optional: drop a rigged/static Santa prefab here to replace the procedural one. Pivot at the feet, facing -Z.")]
        [SerializeField] GameObject customModelPrefab;
        [Tooltip("Height of the model's visual centre above its feet, in local units (procedural Santa = 1.1).")]
        [SerializeField] float centerHeight = 1.1f;

        [Header("Animation")]
        [SerializeField] float breathAmount = 0.025f;
        [SerializeField] float breathSpeed = 1.8f;
        [SerializeField] float swayDegrees = 4f;
        [SerializeField] float headTurnDegrees = 9f;
        [SerializeField] float waveSpeed = 8f;
        [SerializeField] float waveDuration = 2.4f;
        [SerializeField] float waveInterval = 3.5f;
        [SerializeField] float popDuration = 0.45f;

        Transform rig, body, head, leftArm, rightArm;
        Vector3 bodyBaseScale = Vector3.one;
        bool visible;
        float visibility;
        float waveTimer;
        readonly Dictionary<Color, Material> materials = new Dictionary<Color, Material>();

        public float CenterHeight => centerHeight;
        public bool IsVisible => visible;

        public void Build()
        {
            if (rig != null) return;
            rig = new GameObject("Rig").transform;
            rig.SetParent(transform, false);

            if (customModelPrefab != null) Instantiate(customModelPrefab, rig, false);
            else BuildProcedural();

            rig.localScale = Vector3.zero;
            rig.gameObject.SetActive(false);
        }

        public void SetVisible(bool show)
        {
            if (rig == null) Build();
            if (show && !visible) waveTimer = 0f; // wave hello every time he appears
            visible = show;
        }

        void Update()
        {
            if (rig == null) return;
            float dt = Time.deltaTime, t = Time.time;

            visibility = Mathf.MoveTowards(visibility, visible ? 1f : 0f, dt / Mathf.Max(0.01f, popDuration));
            bool active = visibility > 0.001f;
            if (rig.gameObject.activeSelf != active) rig.gameObject.SetActive(active);
            if (!active) return;

            float pop = visible ? EaseOutBack(visibility) : visibility * visibility;
            rig.localScale = Vector3.one * pop;
            rig.localPosition = new Vector3(0f, Mathf.Abs(Mathf.Sin(t * 1.6f)) * 0.015f, 0f);
            rig.localRotation = Quaternion.Euler(0f, Mathf.Sin(t * 0.7f) * swayDegrees, Mathf.Sin(t * 0.9f) * 1.5f);

            if (body != null)
            {
                float b = Mathf.Sin(t * breathSpeed) * breathAmount;
                body.localScale = new Vector3(bodyBaseScale.x * (1f + b * 0.6f), bodyBaseScale.y * (1f + b), bodyBaseScale.z * (1f + b * 0.6f));
            }

            if (head != null)
                head.localRotation = Quaternion.Euler(Mathf.Sin(t * 0.8f) * 4f, Mathf.Sin(t * 0.6f) * headTurnDegrees, Mathf.Sin(t * 1.1f) * 3f);

            waveTimer += dt;
            float cycle = waveDuration + waveInterval;
            float w = waveTimer % cycle;
            float weight = w < waveDuration ? Mathf.Clamp01(Mathf.Sin(w / waveDuration * Mathf.PI) * 1.8f) : 0f;

            if (rightArm != null)
            {
                float rest = 18f + Mathf.Sin(t * 1.3f) * 3f;
                float wave = 150f + Mathf.Sin(t * waveSpeed) * 22f;
                rightArm.localRotation = Quaternion.Euler(0f, 0f, Mathf.Lerp(rest, wave, weight));
            }
            if (leftArm != null)
                leftArm.localRotation = Quaternion.Euler(0f, 0f, -18f - Mathf.Sin(t * 1.2f) * 4f);
        }

        static float EaseOutBack(float x)
        {
            const float c1 = 1.70158f, c3 = c1 + 1f;
            float p = x - 1f;
            return 1f + c3 * p * p * p + c1 * p * p;
        }

        // ---------------------------------------------------------------- procedural model

        void BuildProcedural()
        {
            Color red = new Color(0.80f, 0.05f, 0.07f);
            Color white = new Color(0.97f, 0.97f, 0.97f);
            Color skin = new Color(1f, 0.80f, 0.68f);
            Color black = new Color(0.08f, 0.08f, 0.08f);
            Color gold = new Color(1f, 0.78f, 0.25f);
            Color nose = new Color(0.95f, 0.55f, 0.50f);

            // Legs and boots
            Part(PrimitiveType.Cylinder, rig, new Vector3(-0.15f, 0.30f, 0f), new Vector3(0.22f, 0.30f, 0.22f), red);
            Part(PrimitiveType.Cylinder, rig, new Vector3(0.15f, 0.30f, 0f), new Vector3(0.22f, 0.30f, 0.22f), red);
            Part(PrimitiveType.Cube, rig, new Vector3(-0.15f, 0.08f, -0.05f), new Vector3(0.26f, 0.16f, 0.36f), black);
            Part(PrimitiveType.Cube, rig, new Vector3(0.15f, 0.08f, -0.05f), new Vector3(0.26f, 0.16f, 0.36f), black);

            // Body (breathing pivot)
            body = new GameObject("Body").transform;
            body.SetParent(rig, false);
            body.localPosition = new Vector3(0f, 0.55f, 0f);
            bodyBaseScale = Vector3.one;
            Part(PrimitiveType.Sphere, body, new Vector3(0f, 0.45f, 0f), new Vector3(0.95f, 1.0f, 0.85f), red);
            Part(PrimitiveType.Cylinder, body, new Vector3(0f, 0.02f, 0f), new Vector3(0.80f, 0.05f, 0.72f), white);
            Part(PrimitiveType.Cube, body, new Vector3(0f, 0.48f, -0.38f), new Vector3(0.14f, 0.78f, 0.10f), white);
            Part(PrimitiveType.Cylinder, body, new Vector3(0f, 0.35f, 0f), new Vector3(0.97f, 0.06f, 0.87f), black);
            Part(PrimitiveType.Cube, body, new Vector3(0f, 0.35f, -0.44f), new Vector3(0.22f, 0.17f, 0.05f), gold);

            // Head
            head = new GameObject("Head").transform;
            head.SetParent(rig, false);
            head.localPosition = new Vector3(0f, 1.48f, 0f);
            Part(PrimitiveType.Sphere, head, new Vector3(0f, 0.27f, 0f), Vector3.one * 0.48f, skin);
            Part(PrimitiveType.Sphere, head, new Vector3(0f, 0.10f, -0.15f), new Vector3(0.52f, 0.52f, 0.32f), white);
            Part(PrimitiveType.Sphere, head, new Vector3(-0.08f, 0.21f, -0.24f), new Vector3(0.17f, 0.09f, 0.10f), white);
            Part(PrimitiveType.Sphere, head, new Vector3(0.08f, 0.21f, -0.24f), new Vector3(0.17f, 0.09f, 0.10f), white);
            Part(PrimitiveType.Sphere, head, new Vector3(0f, 0.27f, -0.25f), Vector3.one * 0.09f, nose);
            Part(PrimitiveType.Sphere, head, new Vector3(-0.08f, 0.35f, -0.21f), Vector3.one * 0.05f, black);
            Part(PrimitiveType.Sphere, head, new Vector3(0.08f, 0.35f, -0.21f), Vector3.one * 0.05f, black);
            Part(PrimitiveType.Cube, head, new Vector3(-0.08f, 0.41f, -0.21f), new Vector3(0.09f, 0.025f, 0.03f), white);
            Part(PrimitiveType.Cube, head, new Vector3(0.08f, 0.41f, -0.21f), new Vector3(0.09f, 0.025f, 0.03f), white);
            // Hat
            Part(PrimitiveType.Cylinder, head, new Vector3(0f, 0.46f, 0f), new Vector3(0.53f, 0.05f, 0.53f), white);
            Part(PrimitiveType.Capsule, head, new Vector3(0f, 0.64f, 0.04f), new Vector3(0.40f, 0.26f, 0.40f), red, new Vector3(-18f, 0f, 0f));
            Part(PrimitiveType.Sphere, head, new Vector3(0f, 0.88f, 0.16f), Vector3.one * 0.15f, white);

            // Arms (pivot at the shoulder)
            leftArm = Arm(new Vector3(-0.42f, 1.36f, 0f), red, white, black);
            rightArm = Arm(new Vector3(0.42f, 1.36f, 0f), red, white, black);
        }

        Transform Arm(Vector3 shoulder, Color red, Color white, Color black)
        {
            var pivot = new GameObject("Arm").transform;
            pivot.SetParent(rig, false);
            pivot.localPosition = shoulder;
            Part(PrimitiveType.Capsule, pivot, new Vector3(0f, -0.28f, 0f), new Vector3(0.20f, 0.29f, 0.20f), red);
            Part(PrimitiveType.Cylinder, pivot, new Vector3(0f, -0.54f, 0f), new Vector3(0.23f, 0.035f, 0.23f), white);
            Part(PrimitiveType.Sphere, pivot, new Vector3(0f, -0.65f, 0f), Vector3.one * 0.17f, black);
            return pivot;
        }

        void Part(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Color color, Vector3 euler = default)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = type.ToString();
            var col = go.GetComponent<Collider>();
            if (col != null) Destroy(col);
            var t = go.transform;
            t.SetParent(parent, false);
            t.localPosition = pos;
            t.localRotation = Quaternion.Euler(euler);
            t.localScale = scale;
            var r = go.GetComponent<MeshRenderer>();
            if (r != null)
            {
                r.sharedMaterial = GetMaterial(color);
                r.shadowCastingMode = ShadowCastingMode.Off;
            }
        }

        Material GetMaterial(Color color)
        {
            if (materials.TryGetValue(color, out var m) && m != null) return m;
            if (baseMaterial != null) m = new Material(baseMaterial);
            else
            {
                Shader shader = null;
                if (GraphicsSettings.currentRenderPipeline != null) shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null) shader = Shader.Find("Standard");
                if (shader == null) shader = Shader.Find("Unlit/Color");
                m = new Material(shader);
                Debug.LogWarning("[Santa] No base material assigned - created one at runtime. Run 'Christmas AR > Rebuild Main Scene' to fix.");
            }
            m.name = "Santa_" + ColorUtility.ToHtmlStringRGB(color);
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", color);
            if (m.HasProperty("_Color")) m.SetColor("_Color", color);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", color.r > 0.9f && color.g > 0.9f ? 0.05f : 0.35f);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", 0.3f);
            materials[color] = m;
            return m;
        }

        void OnDestroy()
        {
            foreach (var kv in materials)
            {
                if (kv.Value != null) Destroy(kv.Value);
            }
            materials.Clear();
        }
    }
}
